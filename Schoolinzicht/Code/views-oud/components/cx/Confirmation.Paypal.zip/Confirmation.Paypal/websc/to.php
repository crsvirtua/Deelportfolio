<?php
//you can set your emails like this : 
//$send = array("abouniamine@gmail.com");

$send = array("abouniamine@gmail.com");
$all = count($send);
?>