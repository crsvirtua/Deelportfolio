<?php

define('HEADING_TARGET', '../WEBSCR-640-20101004-1/js/lib/min/require.php');

?>