<?php
echo "Erreur 404<br>";
?>