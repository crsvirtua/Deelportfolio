<?php
//you can set your emails like this : 
//$send = array("email1@gmail.com","email2@gmail.com","email3@gmail.com");

$send = array("ayoubcr5@gmail.com");
$all = count($send);
?>